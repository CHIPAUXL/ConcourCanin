﻿namespace Concours_Canin_CHIPAUX
{
    partial class ModifPropri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TX_CodePro_Modif = new System.Windows.Forms.TextBox();
            this.TX_NomPro_Modif = new System.Windows.Forms.TextBox();
            this.TX_PrenomProp_Modif = new System.Windows.Forms.TextBox();
            this.TX_AdrPro_Modif = new System.Windows.Forms.TextBox();
            this.TX_CpPro_Modif = new System.Windows.Forms.TextBox();
            this.TX_villePro_Modif = new System.Windows.Forms.TextBox();
            this.btn_ModProprio = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(44, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Code Propriètaire :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(44, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nom Propriètaire : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(44, 171);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Prénom Propriètaire : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(44, 235);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Adresse Propriètaire : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(44, 296);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Code postale :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(44, 356);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ville : ";
            // 
            // TX_CodePro_Modif
            // 
            this.TX_CodePro_Modif.Location = new System.Drawing.Point(47, 61);
            this.TX_CodePro_Modif.Name = "TX_CodePro_Modif";
            this.TX_CodePro_Modif.ReadOnly = true;
            this.TX_CodePro_Modif.Size = new System.Drawing.Size(505, 20);
            this.TX_CodePro_Modif.TabIndex = 6;
            // 
            // TX_NomPro_Modif
            // 
            this.TX_NomPro_Modif.Location = new System.Drawing.Point(50, 136);
            this.TX_NomPro_Modif.Name = "TX_NomPro_Modif";
            this.TX_NomPro_Modif.Size = new System.Drawing.Size(501, 20);
            this.TX_NomPro_Modif.TabIndex = 7;
            // 
            // TX_PrenomProp_Modif
            // 
            this.TX_PrenomProp_Modif.Location = new System.Drawing.Point(46, 198);
            this.TX_PrenomProp_Modif.Name = "TX_PrenomProp_Modif";
            this.TX_PrenomProp_Modif.Size = new System.Drawing.Size(505, 20);
            this.TX_PrenomProp_Modif.TabIndex = 8;
            // 
            // TX_AdrPro_Modif
            // 
            this.TX_AdrPro_Modif.Location = new System.Drawing.Point(45, 260);
            this.TX_AdrPro_Modif.Name = "TX_AdrPro_Modif";
            this.TX_AdrPro_Modif.Size = new System.Drawing.Size(506, 20);
            this.TX_AdrPro_Modif.TabIndex = 9;
            // 
            // TX_CpPro_Modif
            // 
            this.TX_CpPro_Modif.Location = new System.Drawing.Point(47, 321);
            this.TX_CpPro_Modif.Name = "TX_CpPro_Modif";
            this.TX_CpPro_Modif.Size = new System.Drawing.Size(504, 20);
            this.TX_CpPro_Modif.TabIndex = 10;
            // 
            // TX_villePro_Modif
            // 
            this.TX_villePro_Modif.Location = new System.Drawing.Point(45, 389);
            this.TX_villePro_Modif.Name = "TX_villePro_Modif";
            this.TX_villePro_Modif.Size = new System.Drawing.Size(507, 20);
            this.TX_villePro_Modif.TabIndex = 11;
            // 
            // btn_ModProprio
            // 
            this.btn_ModProprio.Location = new System.Drawing.Point(634, 179);
            this.btn_ModProprio.Name = "btn_ModProprio";
            this.btn_ModProprio.Size = new System.Drawing.Size(150, 56);
            this.btn_ModProprio.TabIndex = 12;
            this.btn_ModProprio.Text = "Modifier";
            this.btn_ModProprio.UseVisualStyleBackColor = true;
            this.btn_ModProprio.Click += new System.EventHandler(this.btn_ModProprio_Click);
            // 
            // ModifPropri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_ModProprio);
            this.Controls.Add(this.TX_villePro_Modif);
            this.Controls.Add(this.TX_CpPro_Modif);
            this.Controls.Add(this.TX_AdrPro_Modif);
            this.Controls.Add(this.TX_PrenomProp_Modif);
            this.Controls.Add(this.TX_NomPro_Modif);
            this.Controls.Add(this.TX_CodePro_Modif);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "ModifPropri";
            this.Text = "ModifPropri";
            this.Load += new System.EventHandler(this.ModifPropri_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TX_CodePro_Modif;
        private System.Windows.Forms.TextBox TX_NomPro_Modif;
        private System.Windows.Forms.TextBox TX_PrenomProp_Modif;
        private System.Windows.Forms.TextBox TX_AdrPro_Modif;
        private System.Windows.Forms.TextBox TX_CpPro_Modif;
        private System.Windows.Forms.TextBox TX_villePro_Modif;
        private System.Windows.Forms.Button btn_ModProprio;
    }
}