﻿namespace Concours_Canin_CHIPAUX
{
    partial class AjoutPropri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TX_CodePro = new System.Windows.Forms.TextBox();
            this.TX_NomPro = new System.Windows.Forms.TextBox();
            this.TX_PrenomPro = new System.Windows.Forms.TextBox();
            this.TX_AdrPro = new System.Windows.Forms.TextBox();
            this.TX_cpPro = new System.Windows.Forms.TextBox();
            this.TX_VillePro = new System.Windows.Forms.TextBox();
            this.btn_Ajout = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(33, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Code Propriètaire :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(33, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nom Propriétaire :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(33, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Prénom Propriètaire :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(33, 234);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Adresse :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(33, 296);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Code Postale : ";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(41, 349);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ville :";
            // 
            // TX_CodePro
            // 
            this.TX_CodePro.Location = new System.Drawing.Point(39, 59);
            this.TX_CodePro.Name = "TX_CodePro";
            this.TX_CodePro.Size = new System.Drawing.Size(473, 20);
            this.TX_CodePro.TabIndex = 6;
            // 
            // TX_NomPro
            // 
            this.TX_NomPro.Location = new System.Drawing.Point(39, 126);
            this.TX_NomPro.Name = "TX_NomPro";
            this.TX_NomPro.Size = new System.Drawing.Size(468, 20);
            this.TX_NomPro.TabIndex = 7;
            // 
            // TX_PrenomPro
            // 
            this.TX_PrenomPro.Location = new System.Drawing.Point(40, 195);
            this.TX_PrenomPro.Name = "TX_PrenomPro";
            this.TX_PrenomPro.Size = new System.Drawing.Size(466, 20);
            this.TX_PrenomPro.TabIndex = 8;
            // 
            // TX_AdrPro
            // 
            this.TX_AdrPro.Location = new System.Drawing.Point(43, 264);
            this.TX_AdrPro.Name = "TX_AdrPro";
            this.TX_AdrPro.Size = new System.Drawing.Size(462, 20);
            this.TX_AdrPro.TabIndex = 9;
            // 
            // TX_cpPro
            // 
            this.TX_cpPro.Location = new System.Drawing.Point(40, 318);
            this.TX_cpPro.Name = "TX_cpPro";
            this.TX_cpPro.Size = new System.Drawing.Size(466, 20);
            this.TX_cpPro.TabIndex = 10;
            // 
            // TX_VillePro
            // 
            this.TX_VillePro.Location = new System.Drawing.Point(40, 375);
            this.TX_VillePro.Name = "TX_VillePro";
            this.TX_VillePro.Size = new System.Drawing.Size(462, 20);
            this.TX_VillePro.TabIndex = 11;
            // 
            // btn_Ajout
            // 
            this.btn_Ajout.Location = new System.Drawing.Point(580, 174);
            this.btn_Ajout.Name = "btn_Ajout";
            this.btn_Ajout.Size = new System.Drawing.Size(165, 40);
            this.btn_Ajout.TabIndex = 12;
            this.btn_Ajout.Text = "Ajouter.";
            this.btn_Ajout.UseVisualStyleBackColor = true;
            this.btn_Ajout.Click += new System.EventHandler(this.btn_Ajout_Click);
            // 
            // AjoutPropri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Ajout);
            this.Controls.Add(this.TX_VillePro);
            this.Controls.Add(this.TX_cpPro);
            this.Controls.Add(this.TX_AdrPro);
            this.Controls.Add(this.TX_PrenomPro);
            this.Controls.Add(this.TX_NomPro);
            this.Controls.Add(this.TX_CodePro);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AjoutPropri";
            this.Text = "AjoutPropri";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TX_CodePro;
        private System.Windows.Forms.TextBox TX_NomPro;
        private System.Windows.Forms.TextBox TX_PrenomPro;
        private System.Windows.Forms.TextBox TX_AdrPro;
        private System.Windows.Forms.TextBox TX_cpPro;
        private System.Windows.Forms.TextBox TX_VillePro;
        private System.Windows.Forms.Button btn_Ajout;
    }
}