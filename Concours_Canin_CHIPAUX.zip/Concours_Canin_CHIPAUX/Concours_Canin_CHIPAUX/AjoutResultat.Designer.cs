﻿namespace Concours_Canin_CHIPAUX
{
    partial class AjoutResultat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Text_CodeConcours_result = new System.Windows.Forms.TextBox();
            this.Text_Note_result = new System.Windows.Forms.TextBox();
            this.btn_ajout_result = new System.Windows.Forms.Button();
            this.lstChien = new System.Windows.Forms.ListBox();
            this.lstPro = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Code propriètaire : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Code Chien :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(46, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Code Concours : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(41, 278);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Note : ";
            // 
            // Text_CodeConcours_result
            // 
            this.Text_CodeConcours_result.Location = new System.Drawing.Point(44, 82);
            this.Text_CodeConcours_result.Name = "Text_CodeConcours_result";
            this.Text_CodeConcours_result.ReadOnly = true;
            this.Text_CodeConcours_result.Size = new System.Drawing.Size(509, 20);
            this.Text_CodeConcours_result.TabIndex = 6;
            // 
            // Text_Note_result
            // 
            this.Text_Note_result.Location = new System.Drawing.Point(44, 310);
            this.Text_Note_result.Name = "Text_Note_result";
            this.Text_Note_result.Size = new System.Drawing.Size(509, 20);
            this.Text_Note_result.TabIndex = 7;
            // 
            // btn_ajout_result
            // 
            this.btn_ajout_result.Location = new System.Drawing.Point(626, 195);
            this.btn_ajout_result.Name = "btn_ajout_result";
            this.btn_ajout_result.Size = new System.Drawing.Size(126, 30);
            this.btn_ajout_result.TabIndex = 8;
            this.btn_ajout_result.Text = "Ajouter";
            this.btn_ajout_result.UseVisualStyleBackColor = true;
            this.btn_ajout_result.Click += new System.EventHandler(this.btn_ajout_result_Click);
            // 
            // lstChien
            // 
            this.lstChien.FormattingEnabled = true;
            this.lstChien.Location = new System.Drawing.Point(44, 222);
            this.lstChien.Name = "lstChien";
            this.lstChien.Size = new System.Drawing.Size(509, 30);
            this.lstChien.TabIndex = 9;
            // 
            // lstPro
            // 
            this.lstPro.FormattingEnabled = true;
            this.lstPro.Location = new System.Drawing.Point(44, 151);
            this.lstPro.Name = "lstPro";
            this.lstPro.Size = new System.Drawing.Size(509, 30);
            this.lstPro.TabIndex = 10;
            this.lstPro.SelectedIndexChanged += new System.EventHandler(this.lstPro_SelectedIndexChanged);
            // 
            // AjoutResultat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstPro);
            this.Controls.Add(this.lstChien);
            this.Controls.Add(this.btn_ajout_result);
            this.Controls.Add(this.Text_Note_result);
            this.Controls.Add(this.Text_CodeConcours_result);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AjoutResultat";
            this.Text = "AjoutResultat";
            this.Load += new System.EventHandler(this.AjoutResultat_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Text_CodeConcours_result;
        private System.Windows.Forms.TextBox Text_Note_result;
        private System.Windows.Forms.Button btn_ajout_result;
        private System.Windows.Forms.ListBox lstChien;
        private System.Windows.Forms.ListBox lstPro;
    }
}