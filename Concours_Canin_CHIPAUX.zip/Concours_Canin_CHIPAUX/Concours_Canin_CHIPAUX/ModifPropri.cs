﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concours_Canin_CHIPAUX
{
    public partial class ModifPropri : Form
    {
        //Variable de stockage des paramètres 

        string codePro;
        string adrPro;
        string cpPro;
        string nomPro;
        string prenomPro;
        string villePro;

        CONCOURSCANINEntities69 db = new CONCOURSCANINEntities69();

        public ModifPropri(string codeModifPro,string  adrModifPro, string cpModifPro, string nomModifPro, string prenomModifPro, string villeModifPro)
        {

            InitializeComponent();

            //Instanciation des variable
            codePro = codeModifPro;
            adrPro = adrModifPro;
            cpPro = cpModifPro;
            nomPro = nomModifPro;
            prenomPro = nomModifPro;
            villePro = villeModifPro;
        }

        private void ModifPropri_Load(object sender, EventArgs e)
        {
            TX_CodePro_Modif.Text = codePro;
            TX_AdrPro_Modif.Text = adrPro;
            TX_CpPro_Modif.Text = cpPro;
            TX_NomPro_Modif.Text = nomPro;
            TX_PrenomProp_Modif.Text = prenomPro;
            TX_villePro_Modif.Text = villePro;
        }

        private void btn_ModProprio_Click(object sender, EventArgs e)
        {
            var query =
                from p in db.PROPRIETAIRE
                where p.codeproprietaire == codePro
                select p;

            foreach (PROPRIETAIRE p in query)
            {
                p.codeproprietaire = TX_CodePro_Modif.Text;
                p.adresseproprietaire = TX_AdrPro_Modif.Text;
                p.cpproprietaire = TX_CpPro_Modif.Text;
                p.nomproprietaire = TX_NomPro_Modif.Text;
                p.prenomproprietaire = TX_PrenomProp_Modif.Text;
                p.villeproprietaire = TX_villePro_Modif.Text;
            }

            try
            {
                db.SaveChanges();
                MessageBox.Show("Le propriètaire a été modifié dans la base de données.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}
