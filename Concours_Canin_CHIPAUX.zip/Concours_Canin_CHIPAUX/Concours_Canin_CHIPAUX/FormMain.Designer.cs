﻿namespace Concours_Canin_CHIPAUX
{
    partial class FormMain
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btn_Modif = new System.Windows.Forms.Button();
            this.btn_Supp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_result = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.btn_AjoutPropri = new System.Windows.Forms.Button();
            this.btn_ModifPropri = new System.Windows.Forms.Button();
            this.btn_SuppPropri = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(22, 143);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(700, 175);
            this.dataGridView1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(728, 156);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(170, 27);
            this.button1.TabIndex = 1;
            this.button1.Text = "Ajouter";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(880, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(55, 31);
            this.button2.TabIndex = 2;
            this.button2.Text = "Refresh";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_Modif
            // 
            this.btn_Modif.Location = new System.Drawing.Point(729, 189);
            this.btn_Modif.Name = "btn_Modif";
            this.btn_Modif.Size = new System.Drawing.Size(170, 26);
            this.btn_Modif.TabIndex = 3;
            this.btn_Modif.Text = "Modifier";
            this.btn_Modif.UseVisualStyleBackColor = true;
            this.btn_Modif.Click += new System.EventHandler(this.btn_Modif_Click);
            // 
            // btn_Supp
            // 
            this.btn_Supp.Location = new System.Drawing.Point(729, 221);
            this.btn_Supp.Name = "btn_Supp";
            this.btn_Supp.Size = new System.Drawing.Size(170, 30);
            this.btn_Supp.TabIndex = 4;
            this.btn_Supp.Text = "Supprimer";
            this.btn_Supp.UseVisualStyleBackColor = true;
            this.btn_Supp.Click += new System.EventHandler(this.btn_Supp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Gestion des Concours :  ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(338, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(318, 42);
            this.label2.TabIndex = 6;
            this.label2.Text = "Concours CANIN";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 336);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Résultat Concours :";
            // 
            // btn_result
            // 
            this.btn_result.Location = new System.Drawing.Point(729, 257);
            this.btn_result.Name = "btn_result";
            this.btn_result.Size = new System.Drawing.Size(169, 24);
            this.btn_result.TabIndex = 8;
            this.btn_result.Text = "Ajouter un Résultat";
            this.btn_result.UseVisualStyleBackColor = true;
            this.btn_result.Click += new System.EventHandler(this.btn_result_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(22, 375);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(913, 112);
            this.dataGridView2.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(37, 511);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(299, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "Gestion des propriètaires : ";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(22, 563);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(685, 149);
            this.dataGridView3.TabIndex = 11;
            // 
            // btn_AjoutPropri
            // 
            this.btn_AjoutPropri.Location = new System.Drawing.Point(728, 563);
            this.btn_AjoutPropri.Name = "btn_AjoutPropri";
            this.btn_AjoutPropri.Size = new System.Drawing.Size(170, 40);
            this.btn_AjoutPropri.TabIndex = 12;
            this.btn_AjoutPropri.Text = "Ajouter";
            this.btn_AjoutPropri.UseVisualStyleBackColor = true;
            this.btn_AjoutPropri.Click += new System.EventHandler(this.btn_AjoutPropri_Click);
            // 
            // btn_ModifPropri
            // 
            this.btn_ModifPropri.Location = new System.Drawing.Point(728, 619);
            this.btn_ModifPropri.Name = "btn_ModifPropri";
            this.btn_ModifPropri.Size = new System.Drawing.Size(170, 37);
            this.btn_ModifPropri.TabIndex = 13;
            this.btn_ModifPropri.Text = "Modifier";
            this.btn_ModifPropri.UseVisualStyleBackColor = true;
            this.btn_ModifPropri.Click += new System.EventHandler(this.btn_ModifPropri_Click);
            // 
            // btn_SuppPropri
            // 
            this.btn_SuppPropri.Location = new System.Drawing.Point(728, 672);
            this.btn_SuppPropri.Name = "btn_SuppPropri";
            this.btn_SuppPropri.Size = new System.Drawing.Size(167, 40);
            this.btn_SuppPropri.TabIndex = 14;
            this.btn_SuppPropri.Text = "Supprimer";
            this.btn_SuppPropri.UseVisualStyleBackColor = true;
            this.btn_SuppPropri.Click += new System.EventHandler(this.btn_SuppPropri_Click);
            // 
            // FormMain
            // 
            this.ClientSize = new System.Drawing.Size(947, 768);
            this.Controls.Add(this.btn_SuppPropri);
            this.Controls.Add(this.btn_ModifPropri);
            this.Controls.Add(this.btn_AjoutPropri);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btn_result);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Supp);
            this.Controls.Add(this.btn_Modif);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FormMain";
            this.Text = " ";
            this.Load += new System.EventHandler(this.FormMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
     
     
       
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btn_Modif;
        private System.Windows.Forms.Button btn_Supp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_result;
        private System.Windows.Forms.DataGridView dataGridView2;
        
        private System.Windows.Forms.DataGridViewTextBoxColumn codeproprietaireDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codechienDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn noteDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView3;
       
        private System.Windows.Forms.DataGridViewTextBoxColumn codeproprietaireDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresseproprietaireDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cpproprietaireDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomproprietaireDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prenomproprietaireDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn villeproprietaireDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btn_AjoutPropri;
        private System.Windows.Forms.Button btn_ModifPropri;
        private System.Windows.Forms.Button btn_SuppPropri;
    }
}

