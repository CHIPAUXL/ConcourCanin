﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concours_Canin_CHIPAUX
{
    public partial class AjoutPropri : Form
    {
        public AjoutPropri()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btn_Ajout_Click(object sender, EventArgs e)
        {
            using (var context = new CONCOURSCANINEntities69()) //définit la base utilisé 
            {
                string codePro = TX_CodePro.Text;
                string nomPro = TX_NomPro.Text;
                string prenomPro = TX_PrenomPro.Text;
                string adrPro = TX_AdrPro.Text;
                string cpPro = TX_cpPro.Text;
                string villePro = TX_VillePro.Text;


                var NewPropri = new PROPRIETAIRE
                {
                    codeproprietaire = codePro , 
                    adresseproprietaire = adrPro ,
                    cpproprietaire = cpPro,
                    nomproprietaire = nomPro , 
                    prenomproprietaire = prenomPro , 
                    villeproprietaire = villePro
                };

                context.PROPRIETAIRE.Add(NewPropri);

                try
                {
                    context.SaveChangesAsync();
                    MessageBox.Show("Propriètaire ajouté à la base de donnée.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
        
        }
    }
}
