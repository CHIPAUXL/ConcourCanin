﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concours_Canin_CHIPAUX
{
    public partial class ModifConcours : Form
    {
        //On définit des variable a l'interieur des la classe permettant de récuperer les variable mis en paramètre 
        string Code;
        string Adr;
        string Cp;
        DateTime Date;
        string Salle;
        string Ville;

        CONCOURSCANINEntities69 db = new CONCOURSCANINEntities69();

        public ModifConcours(string codeModif , string adrModif , string cpModif, DateTime dateModif , string salleModif , string villeConcours)
        {
            InitializeComponent();

            //récupereration des données fournit en paramètre
            Code = codeModif;
            Adr = adrModif;
            Cp = cpModif;
            Date = dateModif;
            Salle = salleModif;
            Ville = villeConcours;
        }

        private void ModifConcours_Load(object sender, EventArgs e)
        {
            //Remplissage des TextBox avec les données récuperer 

            Text_CodeConcoursModif.Text = Code;
            Text_AdresseConcoursModif.Text = Adr;
            Text_CpConcoursModif.Text = Cp;
            DateTimeConcoursModif.Value = Date;
            Text_SalleConcoursModif.Text = Salle;
            Text_VilleConcoursModif.Text = Ville;
        }

        private void btnModif_Click(object sender, EventArgs e)
        {
            //requete de maj 
            var query =
                from c in db.CONCOURS
                where c.codeconcours == Code
                select c ;


            foreach (CONCOURS c in query)
            {
                c.adresseconcours = Text_AdresseConcoursModif.Text;
                c.cpconcours = Text_CpConcoursModif.Text;
                c.dateconcours = DateTimeConcoursModif.Value;
                c.salleconcours = Text_SalleConcoursModif.Text;
                c.villeconcours = Text_VilleConcoursModif.Text;
            }

            try
            {
                db.SaveChanges();
                MessageBox.Show("Concours modifié dans la base de données.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}
