﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concours_Canin_CHIPAUX
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }
        CONCOURSCANINEntities69 objet = new CONCOURSCANINEntities69(); //Utilisation de Entities FrameWork

        #region Chargement des DataGridViews
        private void FormMain_Load(object sender, EventArgs e)
        {
            //Chargement du datagridview concours

            var req1 = from c in objet.CONCOURS select c;
            dataGridView1.DataSource = req1.ToList();

            //On n'affiche pas les colones qui ne nous interreses pas
            
            dataGridView1.Columns[6].Visible = false; 

            //Chargement du datagridview Participe

            var req2 = from pa in objet.PARTICIPE select pa;
            dataGridView2.DataSource = req2.ToList();

            //On n'affiche pas les colones qui ne nous interreses pas

            dataGridView2.Columns[4].Visible = false;
            dataGridView2.Columns[5].Visible = false;

            //Chargement du datagridview Proprietaire

            var req3 = from p in objet.PROPRIETAIRE select p;
            dataGridView3.DataSource = req3.ToList();

            //On n'affiche pas les colones qui ne nous interreses pas

            dataGridView3.Columns[6].Visible = false;
        }
        #endregion


        #region Fonction de suppression
        public void DelPart(string id) //Supression dans la table Participant
        {
            PARTICIPE part;
            objet.Database.Log = Console.WriteLine;
            try
            {
                part = objet.PARTICIPE.Where(p => p.codeconcours == id).First();
                objet.PARTICIPE.Remove(part);
                objet.SaveChanges();
                return;
            }
            catch
            {
                return;
            }
        }
        public void DelConcour(string id) //Suppression dans la table concours
        {
            CONCOURS c;
            objet.Database.Log = Console.WriteLine;
            c = objet.CONCOURS.Where(d => d.codeconcours == id).First();
            objet.CONCOURS.Remove(c);
            objet.SaveChanges();
        }

        public void DelPropri(string id) // Suppression dans la table Propriétaire
        {
            PROPRIETAIRE pro;
            objet.Database.Log = Console.WriteLine;
            pro = objet.PROPRIETAIRE.Where(pr => pr.codeproprietaire == id).First();
            objet.PROPRIETAIRE.Remove(pro);
            objet.SaveChanges();
        }
        #endregion


        #region btn refresh
        private void refresh()
        {
           
           
            dataGridView1.DataSource = null; //On supprime la source
            var req1 = from c in objet.CONCOURS select c; // on interroge la BDD 
            dataGridView1.DataSource = req1.ToList(); //On affecte de nouveau la source
            dataGridView1.Columns[6].Visible = false;

            dataGridView2.DataSource = null; //On supprime la source
            var req2 = from pa in objet.PARTICIPE select pa;  // on interroge la BDD 
            dataGridView2.DataSource = req2.ToList();//On affecte de nouveau la source 
            dataGridView2.Columns[4].Visible = false;
            dataGridView2.Columns[5].Visible = false;

            dataGridView3.DataSource = null; //On supprime la source
            var req3 = from p in objet.PROPRIETAIRE select p;  // on interroge la BDD 
            dataGridView3.DataSource = req3.ToList(); //On affecte de nouveau la source
            dataGridView3.Columns[6].Visible = false;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            refresh();
        }

        #endregion


        #region Gestion concours
        private void button1_Click_1(object sender, EventArgs e) //Ajouter un concours. 
        {
            AjouterConcours AjouterConcours = new AjouterConcours(); //On créer un nouveau formulaire
            AjouterConcours.ShowDialog(); //On affiche le nouveau formulaire
        }
        
        private void btn_Supp_Click(object sender, EventArgs e)
        {
 
            
            string id = (string)dataGridView1.CurrentRow.Cells[0].Value; //Récupération de code concours 

            if (MessageBox.Show(this, "Etes-vous sur de vouloir supprimer ?", "Suppression !", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DelPart(id); //on supprime les données dans les 2 tables 
                DelConcour(id);
                refresh();
            }
        }


        private void btn_Modif_Click(object sender, EventArgs e)
        {
            string codeModif = (string)dataGridView1.CurrentRow.Cells[0].Value;
            string adrModif = (string)dataGridView1.CurrentRow.Cells[1].Value;
            string cpModif = (string)dataGridView1.CurrentRow.Cells[2].Value;
            DateTime dateModif = (DateTime)dataGridView1.CurrentRow.Cells[3].Value;
            string salleModif = (string)dataGridView1.CurrentRow.Cells[4].Value;
            string villeConcours = (string)dataGridView1.CurrentRow.Cells[5].Value;

            //Avant de définir le nouveau form on doit récupérer les donnée présent dans le datagridview 

            ModifConcours modifConcours = new ModifConcours(codeModif, adrModif,  cpModif, dateModif,  salleModif,  villeConcours); //On définit le nouveau form en lui envoyant les données en paramètres 
            modifConcours.ShowDialog();


        }

        #endregion



        #region ajout de résultat 
        private void btn_result_Click(object sender, EventArgs e)
        {
            string codeResult = (string)dataGridView1.CurrentRow.Cells[0].Value; //On récupere le code concours présent dans le premier datagridview 

            AjoutResultat AjoutResultat = new AjoutResultat(codeResult); // on instancie le formulaire avec un paramètre 
            AjoutResultat.ShowDialog();
        }
        #endregion


        #region Gestion des Propriétaire

        private void btn_AjoutPropri_Click(object sender, EventArgs e)
        {
            AjoutPropri ajoutPropri = new AjoutPropri(); //Instancie un nouveau form 
            ajoutPropri.ShowDialog();
        }

        private void btn_ModifPropri_Click(object sender, EventArgs e)
        {
            string codeModifPro = (string)dataGridView3.CurrentRow.Cells[0].Value;
            string adrModifPro = (string)dataGridView3.CurrentRow.Cells[1].Value;
            string cpModifPro = (string)dataGridView3.CurrentRow.Cells[2].Value;
            string nomModifPro = (string)dataGridView3.CurrentRow.Cells[3].Value;
            string prenomModifPro = (string)dataGridView3.CurrentRow.Cells[4].Value;
            string villeModifPro = (string)dataGridView3.CurrentRow.Cells[5].Value;

            //On récupere les données afficher dans le datagridview 

            ModifPropri modifPropri = new ModifPropri(codeModifPro, adrModifPro, cpModifPro, nomModifPro, prenomModifPro, villeModifPro); //Instance avec paramètres 
            modifPropri.ShowDialog();
        }

        private void btn_SuppPropri_Click(object sender, EventArgs e)
        {
            string id = (string)dataGridView3.CurrentRow.Cells[0].Value; //récuperation de l'index de la ligne a supprimer

            if (MessageBox.Show(this, "Etes-vous sur de vouloir supprimer ?", "Suppression !", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DelPropri(id);
                refresh();
            }
        }
        #endregion
    }

}
