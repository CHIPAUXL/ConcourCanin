﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concours_Canin_CHIPAUX
{
    public partial class AjoutResultat : Form
    {
        string codeConcoursResult;

        CONCOURSCANINEntities69 db = new CONCOURSCANINEntities69();

        public AjoutResultat(string codeResult)
        {
            InitializeComponent();

            codeConcoursResult = codeResult;
        }

        private void AjoutResultat_Load(object sender, EventArgs e)
        {
            Text_CodeConcours_result.Text = codeConcoursResult;

            var selectProprio = from part in db.PARTICIPE
                                join pro in db.PROPRIETAIRE on part.codeproprietaire equals pro.codeproprietaire
                                where part.codeconcours == codeConcoursResult
                                select pro;

            var Listpro = selectProprio.ToList();

            foreach (var p in Listpro)
            {
                lstPro.Items.Add(new ListItem {ID = p.codeproprietaire, Nom = p.nomproprietaire , Prenom = p.prenomproprietaire });
            }
        }

        private void lstPro_SelectedIndexChanged(object sender, EventArgs e)
        {
            string id = ((ListItem)lstPro.SelectedItem).ID;

            var selectChien = from ch in db.CHIEN
                              join pro in db.PROPRIETAIRE on ch.codeproprietaire equals pro.codeproprietaire
                              where ch.codeproprietaire == id
                              select ch;

            var Listchien = selectChien.ToList();

            foreach (var ch in Listchien)
            {
                lstChien.Items.Add(new ListItem { ID = ch.codechien, Nom = ch.nomchien });
            }
        }

        private void btn_ajout_result_Click(object sender, EventArgs e)
        {
            string idconcours = Text_CodeConcours_result.Text; 
            string idproprio = ((ListItem)lstPro.SelectedItem).ID;
            string idchien = ((ListItem)lstChien.SelectedItem).ID;
            int note = Convert.ToInt32( Text_Note_result.Text); 
           


            var query = from part in db.PARTICIPE
                        where part.codeconcours == idconcours
                        select part; 

            foreach (PARTICIPE part in query)
            {
                part.note = note; 
            }
            try
            {
                db.SaveChanges();
                MessageBox.Show("Note ajoutée.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
    public class ListItem
    {
        public string ID { get; set; }
        public string Nom { get; set; }

        public string Prenom { get; set; }

        public override string ToString()
        {
            return ID + " " + Nom + " " + Prenom;

        }

    }
}
