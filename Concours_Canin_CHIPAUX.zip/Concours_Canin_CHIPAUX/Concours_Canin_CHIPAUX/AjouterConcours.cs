﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Concours_Canin_CHIPAUX
{
    public partial class AjouterConcours : Form
    {
        public AjouterConcours()
        {
            InitializeComponent();
        }

        

        private void button1_Click(object sender, EventArgs e) //Ajout d'un coucours dans la base de donnée 
        {
            using (var context = new CONCOURSCANINEntities69())
            {
                string CodeConcours = Text_CodeConcours.Text;
                string AdresseConcours = Text_AdresseConcours.Text;
                string CpConcours = Text_CpConcours.Text;
                DateTime DateConcours = DateTimeConcours.Value; //Utilisation de .value car le type de la variable est un datetime le .text attend un string 
                string SalleConcours = Text_SalleConcours.Text;
                string VilleConcours = Text_VilleConcours.Text;

                var Newconcours = new CONCOURS 
{
                    codeconcours = CodeConcours,
                    adresseconcours = AdresseConcours,
                    cpconcours = CpConcours,
                    dateconcours = DateConcours,
                    salleconcours = SalleConcours,
                    villeconcours = VilleConcours
                };

                context.CONCOURS.Add(Newconcours);
                
                try
                {
                    context.SaveChangesAsync();
                    MessageBox.Show("Concours ajouté à la base de donnée.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }


            }
            


        }
    }
}
