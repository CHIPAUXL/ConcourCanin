﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassesMetiers;
using MySql.Data.MySqlClient;

namespace ClassesPasserelles
{
    public class RapportPass
    {

        static private DBConnect connect = new DBConnect();

        //Get all Rapport from the database
        public static List<Rapport> GetRapports()
        {
            List<Rapport> lesRapports = new List<Rapport>(); //Create Rapport list
            Rapport unRapport;
            string id; string date;string motif;string bilan;string idMedecin;string idVisiteur; string nomMedecin; string nomVisiteur;
            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init(); //Init connection
            connexion.Open(); //Open connection
            cmd.Connection = connexion;
            Function doubleInner = new Function(); // Using Function class to generate the query
            //generate the query Inner because we need Visiteur and Medecin informations
            string[] req = new string[8] { "*", "Rapport" , "Visiteur" , "Rapport.idVisiteur" , "Visiteur.idVisiteur" , "Medecin" , "Rapport.idMedecin" , "Medecin.idMedecin" };
            cmd.CommandText = doubleInner.DoubleInnerJoin(req);// Prepare the query
            MySqlDataReader drr = cmd.ExecuteReader();//Send the query and get them all

            while (drr.Read())// Get all the datas from DB
            {
                id = drr.GetString(0);
                date = drr.GetString(1);
                motif = drr.GetString(2);
                bilan = drr.GetString(3);
                idVisiteur = drr.GetString(4);
                idMedecin = drr.GetString(5);
                nomMedecin = drr.GetString(7);
                nomVisiteur = drr.GetString(9);
                double UnId = Convert.ToDouble(id);
                double UnIdv = Convert.ToDouble(idVisiteur);
                double UnIdm = Convert.ToDouble(idMedecin);
                unRapport = new Rapport(UnId, date, motif, bilan, UnIdv,UnIdm, nomMedecin , nomVisiteur); //Create Rapport Object
                lesRapports.Add(unRapport); //Add to the list

            }

            drr.Close();// Close the data reading
            connexion.Close();// Close connexion
            return lesRapports;
        }




        public static void UpdateRapport(string id, string champs)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function update = new Function();
            string[] req = new string[4] { "Rapport", champs, "idRapport", id };
            cmd.CommandText = update.Update(req);
            cmd.ExecuteNonQuery();

            connexion.Close();
        }

        public static void InsertRapport(string date, string motif, string bilan, string idV, string idM)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function insert = new Function();
            string[] req = new string[] { "Rapport", date, motif, bilan, idV, idM };
            cmd.CommandText = insert.Insert(req);
            cmd.ExecuteNonQuery();

            connexion.Close();
        }

        public static void DeleteRapport(string id)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function delete = new Function();
            string[] req = new string[3] { "Rapport", "idRapport", id };
            cmd.CommandText = delete.Delete(req);
            cmd.ExecuteNonQuery();

            connexion.Close();
        }
    }
}
