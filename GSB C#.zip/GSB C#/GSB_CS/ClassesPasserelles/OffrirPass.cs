﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassesMetiers;
using MySql.Data.MySqlClient;

namespace ClassesPasserelles
{
    public class OffrirPass
    {
        static private DBConnect connect = new DBConnect();

        //Get all Offrir from the database
        public static List<Offrir> GetOffrir()
        {
            List<Offrir> lesOffres = new List<Offrir>();
            Offrir uneOffre;
            string idMedi; string idRapport; string Quantite; string unNomMedi;
            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init(); //Init connection
            connexion.Open();//Open connection
            cmd.Connection = connexion;
            Function Inner = new Function();// Using Function class to generate the query
            //generate the query Inner because we need Medicament name
            string[] req = new string[5] { "*", "Offrir" , "Medicament" ,"Offrir.idMedicament" ,"Medicament.idMedicament" };
            cmd.CommandText = Inner.InnerJoin(req);// Prepare the query
            MySqlDataReader drr = cmd.ExecuteReader();//Send the query and get them all

            while(drr.Read())// Get all the datas from DB
            {
                idMedi = drr.GetString(0);
                idRapport = drr.GetString(1);
                Quantite = drr.GetString(2);
                unNomMedi = drr.GetString(6);
                double UnidMedi = Convert.ToDouble(idMedi);
                double UnIdRapport = Convert.ToDouble(idRapport);
                int UneQuantite = Convert.ToInt32(Quantite);

                uneOffre = new Offrir(UnidMedi, UnIdRapport, UneQuantite , unNomMedi); //Create Offrir Object
                lesOffres.Add(uneOffre);//Add to the list
            }
            drr.Close();// Close the data reading
            connexion.Close();// Close connexion
            return lesOffres;

        }
        public static void InsertOffrir(string idMedi , string idRapport ,string quantite )
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function insert = new Function();
            string[] req = new string[4] { "offrir", idMedi, idRapport, quantite };


            cmd.CommandText = insert.Insert(req);
            cmd.ExecuteNonQuery();
            connexion.Close();
        }
    }
}
