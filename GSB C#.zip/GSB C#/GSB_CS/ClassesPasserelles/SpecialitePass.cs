﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassesMetiers;
using MySql.Data.MySqlClient;

namespace ClassesPasserelles
{
    public class SpecialitePass
    {

            static private DBConnect connect = new DBConnect();

            //Get all Specialite from the database
            public static List<Specialite> GetSpecialites()
            {
                List<Specialite> lesSpecialite = new List<Specialite>(); //Create Specialite List
                Specialite unSpecialite;
                string id; string unLbl;
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection connexion = connect.Init(); //Init connection
                connexion.Open();//Open connection
                cmd.Connection = connexion;
                Function select = new Function();// Using Function class to generate the query
                string[] req = new string[2] { "*", "Specialite" };
                cmd.CommandText = select.Select(req);// Prepare the query
                MySqlDataReader drr = cmd.ExecuteReader();//Send the query and get them all


                while (drr.Read()) // Get all the datas from DB
                {
                    id = drr.GetString(0);
                    unLbl = drr.GetString(1);
                    unSpecialite = new Specialite(id, unLbl); //Create Specialite object
                    lesSpecialite.Add(unSpecialite); //Add to the list
                }
                drr.Close(); // Close the data reading
                connexion.Close();// Close connexion
                return lesSpecialite;
            }

    }


}
