﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace ClassesPasserelles
{
    class DBConnect
    {


        //Informations of connection
        private string server ;
        private string database ;
        private string user ;
        private string password ;
        private string connectionString;
        private MySqlConnection connexion;

        //Constructor
        public DBConnect ()
        {
        }

        //Connection datas and create connection
        public MySqlConnection Init()
        {
            server = "127.0.0.1";
            database = "gsbc#";
            password = "";
            user = "root";
            connectionString = "SERVER=" + server + ";DATABASE=" + database + ";UID=" + user + ";PASSWORD=" + password;
            connexion = new MySqlConnection(connectionString);
            return connexion;
        }

        // Open the connection and manage error
        private bool OpenConnection()
        {
            string message = "";
            try
            {
                connexion.Open();
                return true;
            }
            catch (MySqlException ex)
            {
               switch (ex.Number)
                {
                    case 0:
                        message = "Cannot connect to server. Please contact administrator !";
                        break;
                    case 1045:
                        message = "Invalid username/password, please try again";
                        break;
                }
                return false;
            }
            
        }

        // Close the connection and manage error
        private bool CloseConnection()
        {
            string message = "";
            try
            {
                connexion.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                message = ex.Message;
                return false;
            }
        }




    }
}
