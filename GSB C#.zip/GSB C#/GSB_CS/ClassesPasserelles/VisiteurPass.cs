﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassesMetiers;
using MySql.Data.MySqlClient;

namespace ClassesPasserelles
{
    public class VisiteurPass
    {
        static private DBConnect connect = new DBConnect();

        //Get all Visiteur from the database
        public static List<Visiteur> GetVisiteurs()
        {
            List<Visiteur> lesVisiteurs = new List<Visiteur>(); //Create Visiteur list
            Visiteur unVisiteur;
            string id; string unNom;
            string unPrenom; string login; string motdepasse; string adresse;
            string cp; string uneVille; string dateEmbauche;
            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();//Init connection
            connexion.Open();//Open connection
            cmd.Connection = connexion;
            Function select = new Function();// Using Function class to generate the query
            string[] req = new string[2] { "*", "Visiteur" };
            cmd.CommandText = select.Select(req);// Prepare the query
            MySqlDataReader drr = cmd.ExecuteReader();//Send the query and get them all

            while (drr.Read())// Get all the datas from DB
            {
                id = drr.GetString(0);
                unNom = drr.GetString(1);
                unPrenom = drr.GetString(2);
                login = drr.GetString(3);
                motdepasse = drr.GetString(4);
                adresse = drr.GetString(5);
                cp = drr.GetString(6);
                uneVille = drr.GetString(7);
                dateEmbauche = drr.GetString(8);
                double UnId = Convert.ToDouble(id);
                unVisiteur = new Visiteur(UnId, unNom, unPrenom, login, motdepasse, adresse, cp, uneVille,dateEmbauche); //Create Visiteur object
                lesVisiteurs.Add(unVisiteur);//Add to the list
            }
            drr.Close();// Close the data reading
            connexion.Close();// Close connexion
            return lesVisiteurs;
        }


        public static void GetLeVsiteur(string id)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function where = new Function();
            string[] req = new string[4] { "*", "Visiteur", "id", id };
            cmd.CommandText = where.Where(req);


            connexion.Close();
        }

        public static void UpdateVisiteur(string id, string champs)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function update = new Function();
            string[] req = new string[4] { "Visiteur", champs, "id", id };
            cmd.CommandText = update.Update(req);

            cmd.ExecuteNonQuery();
            connexion.Close();
        }

        public static void InsertVisiteur(string nom, string prenom,string login, string mdp, string adresse, string cp, string ville, string dateEmbauche )
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function insert = new Function();
            string[] req = new string[] { "Visiteur", nom, prenom, login, mdp, adresse, cp, ville, dateEmbauche };
            cmd.CommandText = insert.Insert(req);

            cmd.ExecuteNonQuery();
            connexion.Close();
        }

        public static void DeleteVisiteur(string id)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function delete = new Function();
            string[] req = new string[3] { "Visiteur", "id", id };
            cmd.CommandText = delete.Delete(req);

            cmd.ExecuteNonQuery();
            connexion.Close();
        }


    }
}
