﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassesMetiers;
using MySql.Data.MySqlClient;

namespace ClassesPasserelles
{
    public class MedicamentPass
    {

        static private DBConnect connect = new DBConnect();

        //Get all Medicament from the database
        public static List<Medicament> GetMedicaments()
        {
            List<Medicament> lesMedicaments = new List<Medicament>(); //Create Medicament List
            Medicament unMedicament;
            string id; string nom; string composition; string effets; string contreIndication; string idFamille; string libFamille;
            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init(); //Init connection
            connexion.Open(); //Open connection
            cmd.Connection = connexion;
            Function innerjoin = new Function();// Using Function class to generate the query
              //generate the query Inner because we need Famille name
            string[] req = new string[5] { "*", "medicament" ,"famille", "medicament.idFamille" , "famille.idFamille"};
            cmd.CommandText = innerjoin.InnerJoin(req); // Prepare the query
            MySqlDataReader drr = cmd.ExecuteReader(); //Send the query and get them all

            while (drr.Read())// Get all the datas from DB
            {
                id = drr.GetString(0);
                nom = drr.GetString(1);
                composition = drr.GetString(2);
                effets = drr.GetString(3);
                contreIndication = drr.GetString(4);
                idFamille = drr.GetString(5);
                libFamille = drr.GetString(7);
                double UnId = Convert.ToDouble(id);
                double UnIdf = Convert.ToDouble(idFamille);
                unMedicament = new Medicament(UnId, nom, composition, effets, contreIndication,UnIdf, libFamille); //Create Medecin Object
                lesMedicaments.Add(unMedicament); //Add to the list
            }

            drr.Close(); // Close the data reading
            connexion.Close();// Close connexion
            return lesMedicaments;
        }


        public static void GetLeVsiteur(string id)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function where = new Function();
            string[] req = new string[4] { "*", "medicament", "id", id };
            cmd.CommandText = where.Where(req);


            connexion.Close();
        }

        public static void UpdateMedicament(string id, string champs)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function update = new Function();
            string[] req = new string[4] { "medicament", champs, "idMedicament", id };
            cmd.CommandText = update.Update(req);

            cmd.ExecuteNonQuery();
            connexion.Close();
        }

        public static void InsertMedicament(string name, string compo, string effects, string cIndication, string fam)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function insert = new Function();
            string[] req = new string[] { "medicament", name, compo, effects, cIndication, fam };
            cmd.CommandText = insert.Insert(req);

            cmd.ExecuteNonQuery();
            connexion.Close();
        }

        public static void DeleteMedicament(string id)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function delete = new Function();
            string[] req = new string[3] { "medicament", "idMedicament", id };
            cmd.CommandText = delete.Delete(req);

            cmd.ExecuteNonQuery();
            connexion.Close();
        }
    }
}
