﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassesMetiers;
using MySql.Data.MySqlClient;

namespace ClassesPasserelles
{
    public class MedecinPass
    {
        static private DBConnect connect = new DBConnect();

        //Get all Medecin from the database
        public static List<Medecin> GetMedecins()
        {
            List<Medecin> lesMedecin = new List<Medecin>();  // Close the data reading
            Medecin unMedecin;
            string id; string unNom;
            string unPrenom; string uneAdresse;
            string tel; string unDepartement; string unidSpe; string unLib;
            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();//Init connection
            connexion.Open();//Open connection
            cmd.Connection = connexion;
            Function innerjoin = new Function();// Using Function class to generate the query
            //generate the query Inner because we need specialites name
            string[] req = new string[5] { "*", "Medecin", "specialite", "Medecin.idSpecialite","specialite.idSpecialite"};
            cmd.CommandText = innerjoin.InnerJoin(req);// Prepare the query
            MySqlDataReader drr = cmd.ExecuteReader();//Send the query and get them all

            while (drr.Read())// Get all the datas from DB
            {
                id = drr.GetString(0);
                unNom = drr.GetString(1);
                unPrenom = drr.GetString(2);
                uneAdresse = drr.GetString(3);
                tel = drr.GetString(4);
                unDepartement = drr.GetString(5);
                unidSpe = drr.GetString(6);
                unLib = drr.GetString(8);
                double unId = Convert.ToDouble(id);
                double unIdspe = Convert.ToDouble(unidSpe);
                unMedecin = new Medecin(unId, unNom,unPrenom,uneAdresse,tel,unDepartement,unIdspe, unLib);//Create Medecin Object
                lesMedecin.Add(unMedecin); //Add to the list
            }
            drr.Close(); // Close the data reading
            connexion.Close(); // Close connexion
            return lesMedecin;
        }

        public static void GetLeMedecin(string id)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function where = new Function();
            string[] req = new string[4] { "*", "Medecin","id",id};
            cmd.CommandText = where.Where(req);


            connexion.Close();
        }

        public static void UpdateMedecin(string id,string champs)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function update = new Function();
            string[] req = new string[4] {"Medecin", champs,"idMedecin", id };
            cmd.CommandText = update.Update(req);

            cmd.ExecuteNonQuery();
            connexion.Close();

        }

        public static void InsertMedecin(string nom, string prenom, string adresse,string tel,string departement,string idspe)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function insert = new Function();
            string[] req = new string[7] { "medecin",nom,prenom,adresse,tel,departement,idspe};
            cmd.CommandText = insert.Insert(req);


            cmd.ExecuteNonQuery();
            connexion.Close();


        }

        public static void DeleteMedecin(string id)
        {

            MySqlCommand cmd = new MySqlCommand();
            MySqlConnection connexion = connect.Init();
            connexion.Open();
            cmd.Connection = connexion;
            Function delete = new Function();
            string[] req = new string[3] {"Medecin","idMedecin",id};
            cmd.CommandText = delete.Delete(req);

            cmd.ExecuteNonQuery();
            connexion.Close();
        }



    }
}
