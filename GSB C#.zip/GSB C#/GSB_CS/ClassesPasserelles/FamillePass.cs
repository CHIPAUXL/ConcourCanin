﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassesMetiers;
using MySql.Data.MySqlClient;

namespace ClassesPasserelles
{
    public class FamillePass
    {

            static private DBConnect connect = new DBConnect();

            //Get all Famille from the database
            public static List<Famille> GetFamilles()
            {
                List<Famille> lesFamilles = new List<Famille>(); //Create Famille List
                Famille unFamille;
                string id; string unLibelle;
                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection connexion = connect.Init();//Init connection
                connexion.Open(); //Open connection
                cmd.Connection = connexion;
                Function select = new Function(); // Using Function class to generate the query
                string[] req = new string[2] { "*", "Famille" };//generate the query
                cmd.CommandText = select.Select(req);// Prepare the query
                MySqlDataReader drr = cmd.ExecuteReader(); //Send the query and get them all

                     while (drr.Read())// Get all the datas from DB
                     {
                        id = drr.GetString(0);
                        unLibelle = drr.GetString(1);
                        double UnId = Convert.ToDouble(id);
                        unFamille = new Famille(UnId, unLibelle); //Create famille Object
                        lesFamilles.Add(unFamille); //Add to the list
                     }

                drr.Close(); // Close the data reading
                connexion.Close(); // Close connexion
                return lesFamilles;
            }


            public static void GetLeVsiteur(string id)
            {

                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection connexion = connect.Init();
                connexion.Open();
                cmd.Connection = connexion;
                Function where = new Function();
                string[] req = new string[4] { "*", "Famille", "id", id };
                cmd.CommandText = where.Where(req);


                connexion.Close();
            }

            public static void UpdateFamille(string id, string champs)
            {

                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection connexion = connect.Init();
                connexion.Open();
                cmd.Connection = connexion;
                Function update = new Function();
                string[] req = new string[4] { "Famille", champs, "id", id };
                cmd.CommandText = update.Update(req);


                connexion.Close();
            }

            public static void InsertFamille(string libelle)
            {

                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection connexion = connect.Init();
                connexion.Open();
                cmd.Connection = connexion;
                Function insert = new Function();
                string[] req = new string[] { "Famille",libelle};
                cmd.CommandText = insert.Insert(req);


                connexion.Close();
            }

            public static void DeleteFamille(string id)
            {

                MySqlCommand cmd = new MySqlCommand();
                MySqlConnection connexion = connect.Init();
                connexion.Open();
                cmd.Connection = connexion;
                Function delete = new Function();
                string[] req = new string[3] { "Famille", "id", id };
                cmd.CommandText = delete.Delete(req);


                connexion.Close();
            }



    }


}
