﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesPasserelles
{
    /// <summary>
    /// Function file don't have any properties 
    /// or assessors
    /// </summary>
    public class Function
    {

        //Constructor's

        public Function()
        {
        }
        
        //Lors de l'appel Select(string[] req = [champ(s),table])
        public string Select(string[] req)
        {
            return "Select " + req[0] + " from " + req[1];
        }

        //Lors de l'appel Where(string[] req = [champ(s),table,champCond,valeurCond])
        public string Where(string[] req)
        {
            return "Select "+req[0]+" from "+req[1]+" where "+req[2]+" = "+req[3];
        }

        //Lors de l'appel DoubleWhere(string[] req = [champ(s),table,champCond,valeurCond,champCond2,valeurCond2])
        public string DoubleWhere(string[] req)
        {
            return "Select " + req[0] + " from " + req[1] + " where " + req[2] + " = " + req[3] + " and " + req[4]+" = "+req[5];
        }

        //Lors de l'appel Insert(string[] req = [table,var1,var2,var3,var4,...])
        public string Insert(string[] req)
        {
            string table = req[0];

            //Verify the table to adapt the request

            if (table == "famille")
                return "INSERT INTO famille('libelle') VALUES("+req[1]+")";
   
            if (table == "medecin")
                return "INSERT INTO medecin (nom, prenom,adresse,tel, departement, idSpecialite) VALUES('"+req[1]+"','"+ req[2] + "','"+ req[3] + "','"+ req[4] + "','" + req[5] + "','" + req[6] +"')";
            if (table == "medicament")
                return "INSERT INTO medicament (nomCommercial,composition, effets, contreIndications, idFamille) VALUES('" + req[1] + "','" + req[2] + "','" + req[3] + "','" + req[4] + "','" + req[5] +"')";
            if (table == "offrir")
                return "INSERT INTO offrir (idMedicament, idRapport, quantite) VALUES(" + req[1] + "," + req[2] + "," + req[3] +")";
            if (table == "Rapport")
                return "INSERT INTO rapport(date, motif, bilan, idVisiteur, idMedecin) VALUES('" + req[1] + "','" + req[2] + "','" + req[3] + "','" + req[4] + "','" + req[5] + "')"; ;
            if (table == "specialite")
                return "INSERT INTO specialite(libelle) VALUES("+req[1]+","+req[2]+")";
            if (table == "Visiteur")
                return "INSERT INTO visiteur( nom, prenom, login, mdp,adresse, cp, ville, dateEmbauche) VALUES('" + req[1] + "','" + req[2] + "','" + req[3] + "','" + req[4] + "','" + req[5] + "','" + req[6] + "','" + req[7] + "','" + req[8] + "')";

            else
                return "Oops la requête n'a pas sû trouver sa table :/";
        }

        //Lors de l'appel Update(string[] req = [table,(colonne a modifier généré automatiquement),champCond,valeurCond]
        public string Update(string[] req)
        {
            return "Update "+req[0]+" "+req[1]+" where "+req[2] + " = " + req[3];
        }

        //Lors de l'appel InnerJoin(string[] req = [champs,table,table2,tableId1,tableId2]
        public string InnerJoin(string[] req)
        {
            return "SELECT "+req[0]+ " FROM "+req[1]+" INNER JOIN "+req[2]+" ON "+req[3]+" = "+req[4];
        }

        public string DoubleInnerJoin(string[] req)
        {
            return "SELECT " + req[0] + " FROM " + req[1] + " INNER JOIN " + req[2] + " ON " + req[3] + " = " + req[4] + " INNER JOIN " + req[5] + " ON " + req[6] + " = " + req[7];
        }

        public string Delete(string[] req)
        {
            return "DELETE FROM " + req[0] + " WHERE " + req[1] + " = " + req[2];
        }
    }
}
