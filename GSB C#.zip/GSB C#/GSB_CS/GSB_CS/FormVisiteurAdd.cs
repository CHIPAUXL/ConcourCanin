﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;

namespace GSB_CS
{
    public partial class FormVisiteurAdd : Form
    {
        public FormVisiteurAdd()
        {
            InitializeComponent();
        }


        private void btncomfirmajout_Click(object sender, EventArgs e) // Get datas from the form
        {
            string nom = Tx_NomVisiteur.Text;
            string prenom = tx_PrenomVisiteur.Text;
            string login = tx_LoginVisiteur.Text;
            string mdp = tx_mdpVisiteur.Text;
            string adr = tx_adrVisiteur.Text;
            string cp = tx_CPVisiteur.Text;
            string ville = tx_VilleVisiteur.Text;
            string date = date_Visiteur.Value.ToString(); // Get date value from list

            try
            {
                VisiteurPass.InsertVisiteur(nom, prenom, login, mdp, adr, cp, ville, date); //Insert Visiteur in database
                MessageBox.Show("Le visiteur à été ajouté");
            }
            catch (Exception err)
            {
                MessageBox.Show("Erreur : " + err);
            }
        }

        private void btn_affiche_mdp_Click(object sender, EventArgs e) // Display password in clear
        {
           if(tx_mdpVisiteur.UseSystemPasswordChar == true)
            {
                tx_mdpVisiteur.UseSystemPasswordChar = false;
            }
            else
            {
                tx_mdpVisiteur.UseSystemPasswordChar = true;
            }


        }
    }
}
