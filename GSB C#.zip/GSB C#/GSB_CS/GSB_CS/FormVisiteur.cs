﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesMetiers;
using ClassesPasserelles;

namespace GSB_CS
{
    public partial class FormVisiteur : Form
    {


        public FormVisiteur()
        {
            InitializeComponent();
        }

        private void FormVisiteur_Load(object sender, EventArgs e) //Load all datas and refresh them if needed
        {
            List<Visiteur> lesVisiteurs = new List<Visiteur>(); // Create list that'll receive all datas
            lesVisiteurs = VisiteurPass.GetVisiteurs();  // Get Visiteur from database
            foreach (Visiteur v in lesVisiteurs)
            {
                DGVisiteur.Rows.Add(v.Id, v.UnNom, v.UnPrenom, v.UnLogin, v.UnMdp, v.UneAdresse, v.UnCp, v.UneVille, v.DateEmbauche); //Add to datagrind view


            }
        }

        private void btnMod_Click(object sender, EventArgs e)
        {
            if (gbVisiteurMod.Visible == false) // Displaying Update form
            {
                gbVisiteurMod.Visible = true;
            }
        }

        private void DGVisiteur_CellContentClick(object sender, DataGridViewCellEventArgs e) // Get datas for the update form
        {
            nomVisiteurMod.Text = DGVisiteur.CurrentRow.Cells[1].Value.ToString();
            prenomVisiteurMod.Text = DGVisiteur.CurrentRow.Cells[2].Value.ToString();
            loginVisiteurMod.Text = DGVisiteur.CurrentRow.Cells[3].Value.ToString();
            mdpVisiteurMod.Text = DGVisiteur.CurrentRow.Cells[4].Value.ToString();
            adresseVisiteurMod.Text = DGVisiteur.CurrentRow.Cells[5].Value.ToString();
            cpVisiteurMod.Text = DGVisiteur.CurrentRow.Cells[6].Value.ToString();
            villeVisiteurMod.Text = DGVisiteur.CurrentRow.Cells[7].Value.ToString();
            string date = DGVisiteur.CurrentRow.Cells[8].Value.ToString();
            Dt_Embauche.Value = DateTime.Parse(date);

        }

        private void btnConfirmMod_Click(object sender, EventArgs e) //Update function
        {
            string id = DGVisiteur.CurrentRow.Cells[0].Value.ToString();
            string nom = nomVisiteurMod.Text;
            string prenom = prenomVisiteurMod.Text;
            string login = loginVisiteurMod.Text;
            string mdp = mdpVisiteurMod.Text;
            string adr = adresseVisiteurMod.Text;
            string cp = cpVisiteurMod.Text;
            string ville = villeVisiteurMod.Text;
            string date = Dt_Embauche.Value.ToString();

            string champ = "SET nom = '" + nom + "', prenom = '" + prenom + "', login = '" + login + "',mdp ='" + mdp + "', adresse ='" + adr + "', cp = '" + cp + "',ville = '" + ville + "',dateEmbauche ='" + date +"'";

            try
            {
                VisiteurPass.UpdateVisiteur(id, champ);
                MessageBox.Show("Le visiteur à été modifié");
            }
            catch (Exception err)
            {
                MessageBox.Show("Erreur : " + err);
            }
        }
    }
}
