﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;

namespace GSB_CS
{
    public partial class FormOffrir : Form
    {
        public FormOffrir()
        {
            InitializeComponent();
        }
        private void LoadOffrir() //Load all datas and refresh them if needed
        {
            List<Offrir> lesOffres = new List<Offrir>(); // Create list that'll receive all datas
            lesOffres = OffrirPass.GetOffrir(); // Get Offir from database
            foreach (Offrir o in lesOffres)
            {
               DGV_Offrir.Rows.Add(o.IdRap,o.IdMedi,o.NomMedi, o.Quantite); //Add to datagrind view

            }

            List<Rapport> LesRapports = new List<Rapport>();  // Prepare list that receive Rapport
            LesRapports = RapportPass.GetRapports(); // Get Rapport from database
            cb_Rapport.DisplayMember = "id"; // Rapport information that's displayed
            cb_Rapport.ValueMember = "id"; //Rapport value
            cb_Rapport.DataSource = LesRapports; // Select where datas came from

            List<Medicament> LesMedicaments = new List<Medicament>(); // Prepare list that receive Medicament
            LesMedicaments = MedicamentPass.GetMedicaments(); // Get Medicament from database
            cb_Medi.DisplayMember = "nom";  // Medicament information that's displayed
            cb_Medi.ValueMember = "id"; //Medicament value
            cb_Medi.DataSource = LesMedicaments; // Select where datas came from
        }

        private void FormOffrir_Load(object sender, EventArgs e)
        {
            LoadOffrir(); //Load Offri to the list
        }

        private void OffreAdd_Click(object sender, EventArgs e)
        {
            string idMedicament = cb_Medi.SelectedValue.ToString(); // Get value from Medicament list
            string idRapport = cb_Rapport.SelectedValue.ToString(); // Get value from Rapport list
            string qte = tb_Quantite.Text;

            try
            {
                OffrirPass.InsertOffrir(idMedicament, idRapport, qte); //Insert Offir in database
            }
            catch (Exception err)
            {
                MessageBox.Show("Erreur : " + err);
            }
            LoadOffrir();
        }
    }
}
