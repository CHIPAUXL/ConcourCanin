﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;

namespace GSB_CS
{
    public partial class FormRapportAdd : Form
    {
        public FormRapportAdd()
        {
            InitializeComponent();
        }

        private void FormRapportAdd_Load(object sender, EventArgs e) //Create Visiteur and Medecin  list
        {
            List<Visiteur> LesVisiteurs = new List<Visiteur>();
            LesVisiteurs = VisiteurPass.GetVisiteurs();

            list_Visireur.DisplayMember = "unNom"; // Visiteur information that's displayed
            list_Visireur.ValueMember = "id"; //Visiteur value
            list_Visireur.DataSource = LesVisiteurs; // Select where datas came from

            List<Medecin> LesMedecins = new List<Medecin>();
            LesMedecins = MedecinPass.GetMedecins();

            list_medecin.DisplayMember = "nom"; // Medecin information that's displayed
            list_medecin.ValueMember = "id"; //Medecin value
            list_medecin.DataSource = LesMedecins; // Select where datas came from

            date_Rapport.Format = DateTimePickerFormat.Custom;
            date_Rapport.CustomFormat = "yyyy-MM-dd";
        }

        private void button1_Click(object sender, EventArgs e) // Get datas from the form
        {
            string date = date_Rapport.Text;
            string motif = rtx_Motif.Text;
            string bilan = rtx_BilanRapport.Text;
            string visiteur = list_Visireur.SelectedValue.ToString(); // Get value from Visiteur list
            string medecin = list_medecin.SelectedValue.ToString(); // Get value from Medecin list


            try
            {
                RapportPass.InsertRapport(date , motif , bilan , visiteur , medecin); //Insert rapport in database
                MessageBox.Show("Un rapport à été ajouté");
            }
            catch (Exception err)
            {
                MessageBox.Show("Erreur : " + err);
            }
        }
    }
}
