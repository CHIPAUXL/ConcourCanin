﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;
using Loader;

namespace GSB_CS
{
    public partial class FormMedecin : Form
    {



        public FormMedecin()
        {
            InitializeComponent();
        }

        private void loadLstMedecin() //Load all datas and refresh them if needed
        {
            DatasLoader l = new DatasLoader(); //Use loader Class
            l.LoadDatas();
            List<Medecin> lesMedecin = new List<Medecin>(); // Create list that'll receive all datas
            lesMedecin = MedecinPass.GetMedecins(); // Get Mededin from database
            foreach (Medecin m in lesMedecin)
            {

                DGMedecin.Rows.Add(m.Id, m.Nom, m.Prenom, m.Adresse, m.Tel, m.Departement, m.IdSpe, m.Libel); //Add to datagrind view
            }
            List<Specialite> LeSpecialites = new List<Specialite>(); // Prepare list that receive Specialite
            LeSpecialites = SpecialitePass.GetSpecialites(); // Get Specialite from database

            lblMedecinMod.DisplayMember = "Libelle"; // Specialite information that's displayed
            lblMedecinMod.ValueMember = "ID"; //Specialite value
            lblMedecinMod.DataSource = LeSpecialites; // Select where datas came from
        }


        private void FormMedecin_Load(object sender, EventArgs e)
        {
            loadLstMedecin(); //Load Medecin to the list on form load
        }



        private void btnMod_Click(object sender, EventArgs e)
        {
            if(gbMedecinMod.Visible == false) // Displaying Update form
            {
                gbMedecinMod.Visible = true;
            }
        }



        private void btnConfirmMedecinMod_Click(object sender, EventArgs e) //Update function
        {
            string id = DGMedecin.CurrentRow.Cells[0].Value.ToString();
            string nom = nomMedecinMod.Text;
            string prenom = prenomMedecinMod.Text;
            string tel = telMedecinMod.Text;
            string adr = adresseMedecinMod.Text;
            string cp = cpMedecinMod.Text;
            string spe = lblMedecinMod.SelectedValue.ToString();

            string champ = "SET nom ='"+nom+"', prenom = '"+prenom+"', adresse = '"+adr+ "', tel = '"+tel+"', departement = '"+cp+ "', idSpecialite ='" +spe+"'" ;

            try
            {
                MedecinPass.UpdateMedecin(id, champ);//Update function

                DGMedecin.Rows.Clear();//Clear all datas from Data DataGridView
                nomMedecinMod.Clear();
                prenomMedecinMod.Clear();
                telMedecinMod.Clear();
                adresseMedecinMod.Clear();
                cpMedecinMod.Clear();
                loadLstMedecin(); //Then get all medecin with updated datas
                MessageBox.Show("Le medecin à été modifier");

            }
            catch (Exception err)
            {
                MessageBox.Show("Erreur : " + err);
            }
            DGMedecin.Refresh();
        }

        private void DGMedecin_CellContentDoubleClick_1(object sender, DataGridViewCellEventArgs e) // Get datas for the update form
        {
            nomMedecinMod.Text = DGMedecin.CurrentRow.Cells[1].Value.ToString();
            prenomMedecinMod.Text = DGMedecin.CurrentRow.Cells[2].Value.ToString();
            telMedecinMod.Text = DGMedecin.CurrentRow.Cells[4].Value.ToString();
            adresseMedecinMod.Text = DGMedecin.CurrentRow.Cells[3].Value.ToString();
            cpMedecinMod.Text = DGMedecin.CurrentRow.Cells[5].Value.ToString();


            string idspe = DGMedecin.CurrentRow.Cells[6].Value.ToString();
            lblMedecinMod.SelectedIndex = Int32.Parse(idspe) - 1;
        }
    }
}
