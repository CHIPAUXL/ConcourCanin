﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;

namespace GSB_CS
{
    public partial class FormMedicament : Form
    {
        public FormMedicament()
        {
            InitializeComponent();
        }

        private void LoadMedoc() //Load all datas and refresh them if needed
        {

            List<Medicament> lesMedicament = new List<Medicament>();// Create list that'll receive all datas
            lesMedicament = MedicamentPass.GetMedicaments(); // Get Medicament from database
            foreach (Medicament m in lesMedicament)

            {

                DGmedicament.Rows.Add(m.Id, m.Nom, m.Composition, m.Effet, m.ContreIndic, m.IdFam, m.LibFam); //Add to datagrind view
            }

            List<Famille> LesFamilles = new List<Famille>(); // Prepare list that receive Famille
            LesFamilles = FamillePass.GetFamilles(); // Get Famille from database

            ListFamille.DisplayMember = "Libelle"; // Famille information that's displayed
            ListFamille.ValueMember = "Id"; //Famille value
            ListFamille.DataSource = LesFamilles;// Select where datas came from
        }

        private void FormMedicament_Load(object sender, EventArgs e)
        {

            LoadMedoc(); //Load Medicament DGV and Famille list when form is loaded
        }

        private void btn_ModifMedoc_Click(object sender, EventArgs e)
        {
            if(GBmedoc.Visible == false)
            {
                GBmedoc.Visible = true;
            }
        }

        private void DGmedicament_CellContentClick(object sender, DataGridViewCellEventArgs e) // Get datas for the update form
        {
            Tx_NomMedoc.Text = DGmedicament.CurrentRow.Cells[1].Value.ToString();
            Rtx_CompoMedoc.Text = DGmedicament.CurrentRow.Cells[2].Value.ToString();
            Rtx_EffetMedoc.Text = DGmedicament.CurrentRow.Cells[3].Value.ToString();
            Rtx_CIMedoc.Text = DGmedicament.CurrentRow.Cells[4].Value.ToString();

            string idfam = DGmedicament.CurrentRow.Cells[5].Value.ToString();
            ListFamille.SelectedIndex = Int32.Parse(idfam)-1;

        }

        private void button1_Click(object sender, EventArgs e) //Update function
        {
            string id = DGmedicament.CurrentRow.Cells[0].Value.ToString();
            string nom = Tx_NomMedoc.Text;
            string compo = Rtx_CompoMedoc.Text;
            string effet = Rtx_EffetMedoc.Text;
            string Ci = Rtx_CIMedoc.Text;
            string famille = ListFamille.SelectedValue.ToString() ;

            string champ = "SET idMedicament = '" + id + "', nomCommercial ='" + nom + "', composition = '" + compo + "', effets = '" + effet + "', contreIndications = '" + Ci + "', idFamille = '" + famille + "'";

            try
            {
                MedicamentPass.UpdateMedicament(id, champ);
                MessageBox.Show("Le médicament à été modifier");
            }
            catch (Exception err)
            {
                MessageBox.Show("Erreur : " + err);
            }
            DGmedicament.Rows.Clear();
            Tx_NomMedoc.Clear();
            Rtx_CompoMedoc.Clear();
            Rtx_EffetMedoc.Clear();
            Rtx_CIMedoc.Clear();

            LoadMedoc();
        }
    }
}
