﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;

namespace GSB_CS
{
    public partial class FormMedicamentAdd : Form
    {
        public FormMedicamentAdd()
        {
            InitializeComponent();
        }

        private void btn_ConfirmAjoutMedoc_Click(object sender, EventArgs e)  // Get datas from the form
        {
            string nom = Tx_NomMedoc.Text;
            string compo = rtx_CompoMedoc.Text;
            string effet = rtx_EffetMedoc.Text;
            string ctrInd = rtx_CIMedoc.Text;
            string famille = list_FamilleMedoc.SelectedValue.ToString(); // Get value from Famille list

            try
            {
                MedicamentPass.InsertMedicament(nom, compo, effet, ctrInd, famille); //Insert medicament in database
                MessageBox.Show("Le médicament à été ajouté");
            }
            catch (Exception err)
            {
                MessageBox.Show("Erreur : " + err);
            }

        }

        private void FormMedicamentAdd_Load(object sender, EventArgs e) //Create Famille list
        {
            List<Famille> LesFamilles = new List<Famille>();
            LesFamilles = FamillePass.GetFamilles();

            list_FamilleMedoc.DisplayMember = "Libelle"; // Famille information that's displayed
            list_FamilleMedoc.ValueMember = "Id"; //Famille value
            list_FamilleMedoc.DataSource = LesFamilles; // Select where datas came from

        }
    }
}
