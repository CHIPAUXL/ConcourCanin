﻿namespace GSB_CS
{
    partial class FormRapport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.DGrapport = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_ModifRapport = new System.Windows.Forms.Button();
            this.GB_ModifRapport = new System.Windows.Forms.GroupBox();
            this.Rtx_Bilan = new System.Windows.Forms.RichTextBox();
            this.Rtx_Motif = new System.Windows.Forms.RichTextBox();
            this.ListMedecin = new System.Windows.Forms.ComboBox();
            this.ListVisiteur = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_ComfirmRapport = new System.Windows.Forms.Button();
            this.Date_ModifRapport = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.IdRapport = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.motif = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bilan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idVisiteur = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomVisiteur = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idMedecin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomMedecin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DGrapport)).BeginInit();
            this.GB_ModifRapport.SuspendLayout();
            this.SuspendLayout();
            // 
            // DGrapport
            // 
            this.DGrapport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGrapport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IdRapport,
            this.date,
            this.motif,
            this.bilan,
            this.idVisiteur,
            this.nomVisiteur,
            this.idMedecin,
            this.nomMedecin});
            this.DGrapport.Location = new System.Drawing.Point(12, 57);
            this.DGrapport.Name = "DGrapport";
            this.DGrapport.Size = new System.Drawing.Size(570, 489);
            this.DGrapport.TabIndex = 0;
            this.DGrapport.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGrapport_CellContentClick);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(531, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(189, 33);
            this.label8.TabIndex = 28;
            this.label8.Text = "Les rapports";
            // 
            // btn_ModifRapport
            // 
            this.btn_ModifRapport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ModifRapport.Location = new System.Drawing.Point(625, 57);
            this.btn_ModifRapport.Name = "btn_ModifRapport";
            this.btn_ModifRapport.Size = new System.Drawing.Size(720, 47);
            this.btn_ModifRapport.TabIndex = 29;
            this.btn_ModifRapport.Text = "Modifier le rapport sélectionné";
            this.btn_ModifRapport.UseVisualStyleBackColor = true;
            this.btn_ModifRapport.Click += new System.EventHandler(this.btn_ModifRapport_Click);
            // 
            // GB_ModifRapport
            // 
            this.GB_ModifRapport.Controls.Add(this.Rtx_Bilan);
            this.GB_ModifRapport.Controls.Add(this.Rtx_Motif);
            this.GB_ModifRapport.Controls.Add(this.ListMedecin);
            this.GB_ModifRapport.Controls.Add(this.ListVisiteur);
            this.GB_ModifRapport.Controls.Add(this.label5);
            this.GB_ModifRapport.Controls.Add(this.label4);
            this.GB_ModifRapport.Controls.Add(this.btn_ComfirmRapport);
            this.GB_ModifRapport.Controls.Add(this.Date_ModifRapport);
            this.GB_ModifRapport.Controls.Add(this.label3);
            this.GB_ModifRapport.Controls.Add(this.label2);
            this.GB_ModifRapport.Controls.Add(this.label1);
            this.GB_ModifRapport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GB_ModifRapport.Location = new System.Drawing.Point(626, 110);
            this.GB_ModifRapport.Name = "GB_ModifRapport";
            this.GB_ModifRapport.Size = new System.Drawing.Size(732, 534);
            this.GB_ModifRapport.TabIndex = 30;
            this.GB_ModifRapport.TabStop = false;
            this.GB_ModifRapport.Text = "Modifier le rapport. ";
            this.GB_ModifRapport.Visible = false;
            // 
            // Rtx_Bilan
            // 
            this.Rtx_Bilan.Location = new System.Drawing.Point(20, 278);
            this.Rtx_Bilan.Name = "Rtx_Bilan";
            this.Rtx_Bilan.Size = new System.Drawing.Size(689, 48);
            this.Rtx_Bilan.TabIndex = 12;
            this.Rtx_Bilan.Text = "";
            // 
            // Rtx_Motif
            // 
            this.Rtx_Motif.Location = new System.Drawing.Point(21, 176);
            this.Rtx_Motif.Name = "Rtx_Motif";
            this.Rtx_Motif.Size = new System.Drawing.Size(680, 57);
            this.Rtx_Motif.TabIndex = 11;
            this.Rtx_Motif.Text = "";
            // 
            // ListMedecin
            // 
            this.ListMedecin.FormattingEnabled = true;
            this.ListMedecin.Location = new System.Drawing.Point(419, 385);
            this.ListMedecin.Name = "ListMedecin";
            this.ListMedecin.Size = new System.Drawing.Size(282, 21);
            this.ListMedecin.TabIndex = 10;
            // 
            // ListVisiteur
            // 
            this.ListVisiteur.FormattingEnabled = true;
            this.ListVisiteur.Location = new System.Drawing.Point(30, 385);
            this.ListVisiteur.Name = "ListVisiteur";
            this.ListVisiteur.Size = new System.Drawing.Size(268, 21);
            this.ListVisiteur.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(537, 350);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Médecin";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(134, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Visiteur";
            // 
            // btn_ComfirmRapport
            // 
            this.btn_ComfirmRapport.Location = new System.Drawing.Point(228, 445);
            this.btn_ComfirmRapport.Name = "btn_ComfirmRapport";
            this.btn_ComfirmRapport.Size = new System.Drawing.Size(261, 52);
            this.btn_ComfirmRapport.TabIndex = 6;
            this.btn_ComfirmRapport.Text = "Confirmer";
            this.btn_ComfirmRapport.UseVisualStyleBackColor = true;
            this.btn_ComfirmRapport.Click += new System.EventHandler(this.btn_ComfirmRapport_Click);
            // 
            // Date_ModifRapport
            // 
            this.Date_ModifRapport.Location = new System.Drawing.Point(30, 94);
            this.Date_ModifRapport.Name = "Date_ModifRapport";
            this.Date_ModifRapport.Size = new System.Drawing.Size(671, 20);
            this.Date_ModifRapport.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 243);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Bilan rapport : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Date rapport : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Motif rapport : ";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // IdRapport
            // 
            this.IdRapport.HeaderText = "ID";
            this.IdRapport.Name = "IdRapport";
            this.IdRapport.Visible = false;
            // 
            // date
            // 
            this.date.HeaderText = "Date";
            this.date.Name = "date";
            // 
            // motif
            // 
            this.motif.HeaderText = "Motif";
            this.motif.Name = "motif";
            // 
            // bilan
            // 
            this.bilan.HeaderText = "Bilan";
            this.bilan.Name = "bilan";
            // 
            // idVisiteur
            // 
            this.idVisiteur.HeaderText = "Visiteur";
            this.idVisiteur.Name = "idVisiteur";
            this.idVisiteur.Visible = false;
            // 
            // nomVisiteur
            // 
            this.nomVisiteur.HeaderText = "Nom visiteur";
            this.nomVisiteur.Name = "nomVisiteur";
            // 
            // idMedecin
            // 
            this.idMedecin.HeaderText = "Medecin";
            this.idMedecin.Name = "idMedecin";
            this.idMedecin.Visible = false;
            // 
            // nomMedecin
            // 
            this.nomMedecin.HeaderText = "Nom Medecin";
            this.nomMedecin.Name = "nomMedecin";
            // 
            // FormRapport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 686);
            this.Controls.Add(this.GB_ModifRapport);
            this.Controls.Add(this.btn_ModifRapport);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.DGrapport);
            this.Name = "FormRapport";
            this.Text = "Liste des rapports";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormRapport_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGrapport)).EndInit();
            this.GB_ModifRapport.ResumeLayout(false);
            this.GB_ModifRapport.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGrapport;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_ModifRapport;
        private System.Windows.Forms.GroupBox GB_ModifRapport;
        private System.Windows.Forms.Button btn_ComfirmRapport;
        private System.Windows.Forms.DateTimePicker Date_ModifRapport;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox ListMedecin;
        private System.Windows.Forms.ComboBox ListVisiteur;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox Rtx_Bilan;
        private System.Windows.Forms.RichTextBox Rtx_Motif;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdRapport;
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
        private System.Windows.Forms.DataGridViewTextBoxColumn motif;
        private System.Windows.Forms.DataGridViewTextBoxColumn bilan;
        private System.Windows.Forms.DataGridViewTextBoxColumn idVisiteur;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomVisiteur;
        private System.Windows.Forms.DataGridViewTextBoxColumn idMedecin;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomMedecin;
    }
}