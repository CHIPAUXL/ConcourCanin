﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;

namespace GSB_CS
{
    public partial class FormMedicamentDelete : Form
    {
        public FormMedicamentDelete()
        {
            InitializeComponent();
        }

        private void LoadListMedoc ()
        {
            List<Medicament> lesMedicaments = new List<Medicament>(); // Create Medicament List
            lesMedicaments = MedicamentPass.GetMedicaments(); // Get Medicament from database

            list_Medoc.DisplayMember = "nom"; // Medicament formation that's displayed
            list_Medoc.ValueMember = "id"; //Medicament value
            list_Medoc.DataSource = lesMedicaments; // Select where datas came from
        }

        private void FormMedicamentDelete_Load(object sender, EventArgs e)
        {

            LoadListMedoc(); // Load list when form is load
        }

        private void btn_ComfirmSupp_Click(object sender, EventArgs e)
        {
            if (gb_comfirmSupp.Visible == false)
            {
                gb_comfirmSupp.Visible = true;
            }
            else if (cb_yes.Checked == true) // If combobov checked then
            {
                string id = list_Medoc.SelectedValue.ToString(); //Get the Id from list with the ValueMember

                try
                {
                    MedicamentPass.DeleteMedicament(id); //Use delete function
                    MessageBox.Show("Le médicament à été supprimer."); // Inform the user
                }
                catch (Exception err)
                {
                    MessageBox.Show("Erreur : " + err);
                }
                LoadListMedoc(); //Reload Medecin list

            }
        }
    }
}
