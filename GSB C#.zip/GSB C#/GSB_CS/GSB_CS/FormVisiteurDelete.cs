﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;

namespace GSB_CS
{
    public partial class FormVisiteurDelete : Form
    {
        public FormVisiteurDelete()
        {
            InitializeComponent();
        }

        private void FormVisiteurDelete_Load(object sender, EventArgs e)
        {
            List<Visiteur> lesVisiteurs = new List<Visiteur>(); // Create Visiteur List
            lesVisiteurs = VisiteurPass.GetVisiteurs(); // Get Visiteur from database

            list_Visiteur.DisplayMember = "nom"; // Visiteur formation that's displayed
            list_Visiteur.ValueMember = "Id"; // Visiteur value
            list_Visiteur.DataSource = lesVisiteurs; // Select where datas came from

        }

        private void btn_ComfirmSupp_Click(object sender, EventArgs e)
        {
            if (gb_comfirmSupp.Visible == false)
            {
                gb_comfirmSupp.Visible = true;
            }
            else if (cb_yes.Checked == true) // If combobov checked then
            {
                string id = list_Visiteur.SelectedIndex.ToString(); //Get the Id from list with the ValueMember

                try
                {
                    VisiteurPass.DeleteVisiteur(id); //Use delete function
                    MessageBox.Show("Le visiteur à été supprimer."); // Inform the user
                }
                catch (Exception err)
                {
                    MessageBox.Show("Erreur : " + err);
                }

                list_Visiteur.Refresh(); //Reload Medecin list

            }
        }
    }
}
