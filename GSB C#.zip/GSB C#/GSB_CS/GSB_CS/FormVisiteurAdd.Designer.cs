﻿namespace GSB_CS
{
    partial class FormVisiteurAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Tx_NomVisiteur = new System.Windows.Forms.TextBox();
            this.tx_PrenomVisiteur = new System.Windows.Forms.TextBox();
            this.tx_LoginVisiteur = new System.Windows.Forms.TextBox();
            this.tx_mdpVisiteur = new System.Windows.Forms.TextBox();
            this.tx_adrVisiteur = new System.Windows.Forms.TextBox();
            this.tx_CPVisiteur = new System.Windows.Forms.TextBox();
            this.tx_VilleVisiteur = new System.Windows.Forms.TextBox();
            this.date_Visiteur = new System.Windows.Forms.DateTimePicker();
            this.btncomfirmajout = new System.Windows.Forms.Button();
            this.btn_affiche_mdp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Prénom du Visiteur : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nom du Visiteur : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(255, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(286, 33);
            this.label3.TabIndex = 2;
            this.label3.Text = "Ajout d\'un Visiteur. ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(24, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Login du Visiteur :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(24, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(223, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Mot de passe du Visiteur : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(24, 283);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Adresse du Visiteur : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(24, 330);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(212, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Code Postal du Visiteur : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(24, 379);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(145, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "Ville du visiteur : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(24, 430);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(165, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "Date d\'embauche : ";
            // 
            // Tx_NomVisiteur
            // 
            this.Tx_NomVisiteur.Location = new System.Drawing.Point(261, 81);
            this.Tx_NomVisiteur.Name = "Tx_NomVisiteur";
            this.Tx_NomVisiteur.Size = new System.Drawing.Size(1014, 20);
            this.Tx_NomVisiteur.TabIndex = 9;
            // 
            // tx_PrenomVisiteur
            // 
            this.tx_PrenomVisiteur.Location = new System.Drawing.Point(262, 128);
            this.tx_PrenomVisiteur.Name = "tx_PrenomVisiteur";
            this.tx_PrenomVisiteur.Size = new System.Drawing.Size(1013, 20);
            this.tx_PrenomVisiteur.TabIndex = 10;
            // 
            // tx_LoginVisiteur
            // 
            this.tx_LoginVisiteur.Location = new System.Drawing.Point(262, 184);
            this.tx_LoginVisiteur.Name = "tx_LoginVisiteur";
            this.tx_LoginVisiteur.Size = new System.Drawing.Size(1013, 20);
            this.tx_LoginVisiteur.TabIndex = 11;
            // 
            // tx_mdpVisiteur
            // 
            this.tx_mdpVisiteur.Location = new System.Drawing.Point(262, 233);
            this.tx_mdpVisiteur.Name = "tx_mdpVisiteur";
            this.tx_mdpVisiteur.Size = new System.Drawing.Size(887, 20);
            this.tx_mdpVisiteur.TabIndex = 12;
            this.tx_mdpVisiteur.UseSystemPasswordChar = true;
            // 
            // tx_adrVisiteur
            // 
            this.tx_adrVisiteur.Location = new System.Drawing.Point(261, 283);
            this.tx_adrVisiteur.Name = "tx_adrVisiteur";
            this.tx_adrVisiteur.Size = new System.Drawing.Size(1014, 20);
            this.tx_adrVisiteur.TabIndex = 13;
            // 
            // tx_CPVisiteur
            // 
            this.tx_CPVisiteur.Location = new System.Drawing.Point(262, 330);
            this.tx_CPVisiteur.MaxLength = 5;
            this.tx_CPVisiteur.Name = "tx_CPVisiteur";
            this.tx_CPVisiteur.Size = new System.Drawing.Size(1013, 20);
            this.tx_CPVisiteur.TabIndex = 14;
            // 
            // tx_VilleVisiteur
            // 
            this.tx_VilleVisiteur.Location = new System.Drawing.Point(261, 379);
            this.tx_VilleVisiteur.Name = "tx_VilleVisiteur";
            this.tx_VilleVisiteur.Size = new System.Drawing.Size(1014, 20);
            this.tx_VilleVisiteur.TabIndex = 15;
            // 
            // date_Visiteur
            // 
            this.date_Visiteur.Location = new System.Drawing.Point(262, 430);
            this.date_Visiteur.Name = "date_Visiteur";
            this.date_Visiteur.Size = new System.Drawing.Size(1013, 20);
            this.date_Visiteur.TabIndex = 16;
            // 
            // btncomfirmajout
            // 
            this.btncomfirmajout.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncomfirmajout.Location = new System.Drawing.Point(644, 525);
            this.btncomfirmajout.Name = "btncomfirmajout";
            this.btncomfirmajout.Size = new System.Drawing.Size(280, 54);
            this.btncomfirmajout.TabIndex = 17;
            this.btncomfirmajout.Text = "Confirmer ";
            this.btncomfirmajout.UseVisualStyleBackColor = true;
            this.btncomfirmajout.Click += new System.EventHandler(this.btncomfirmajout_Click);
            // 
            // btn_affiche_mdp
            // 
            this.btn_affiche_mdp.Location = new System.Drawing.Point(1168, 234);
            this.btn_affiche_mdp.Name = "btn_affiche_mdp";
            this.btn_affiche_mdp.Size = new System.Drawing.Size(107, 20);
            this.btn_affiche_mdp.TabIndex = 18;
            this.btn_affiche_mdp.Text = "Afficher/Cacher";
            this.btn_affiche_mdp.UseVisualStyleBackColor = true;
            this.btn_affiche_mdp.Click += new System.EventHandler(this.btn_affiche_mdp_Click);
            // 
            // FormVisiteurAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 686);
            this.Controls.Add(this.btn_affiche_mdp);
            this.Controls.Add(this.btncomfirmajout);
            this.Controls.Add(this.date_Visiteur);
            this.Controls.Add(this.tx_VilleVisiteur);
            this.Controls.Add(this.tx_CPVisiteur);
            this.Controls.Add(this.tx_adrVisiteur);
            this.Controls.Add(this.tx_mdpVisiteur);
            this.Controls.Add(this.tx_LoginVisiteur);
            this.Controls.Add(this.tx_PrenomVisiteur);
            this.Controls.Add(this.Tx_NomVisiteur);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormVisiteurAdd";
            this.Text = "Ajouter un visiteur";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox Tx_NomVisiteur;
        private System.Windows.Forms.TextBox tx_PrenomVisiteur;
        private System.Windows.Forms.TextBox tx_LoginVisiteur;
        private System.Windows.Forms.TextBox tx_mdpVisiteur;
        private System.Windows.Forms.TextBox tx_adrVisiteur;
        private System.Windows.Forms.TextBox tx_CPVisiteur;
        private System.Windows.Forms.TextBox tx_VilleVisiteur;
        private System.Windows.Forms.DateTimePicker date_Visiteur;
        private System.Windows.Forms.Button btncomfirmajout;
        private System.Windows.Forms.Button btn_affiche_mdp;
    }
}