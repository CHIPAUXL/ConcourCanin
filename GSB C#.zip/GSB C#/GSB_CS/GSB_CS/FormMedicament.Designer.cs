﻿namespace GSB_CS
{
    partial class FormMedicament
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGmedicament = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_ModifMedoc = new System.Windows.Forms.Button();
            this.GBmedoc = new System.Windows.Forms.GroupBox();
            this.ListFamille = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.Rtx_CIMedoc = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Rtx_EffetMedoc = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Rtx_CompoMedoc = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Tx_NomMedoc = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.composition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.effet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contreIndic = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idfam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LibFamille = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DGmedicament)).BeginInit();
            this.GBmedoc.SuspendLayout();
            this.SuspendLayout();
            // 
            // DGmedicament
            // 
            this.DGmedicament.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGmedicament.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.nom,
            this.composition,
            this.effet,
            this.contreIndic,
            this.idfam,
            this.LibFamille});
            this.DGmedicament.Location = new System.Drawing.Point(21, 77);
            this.DGmedicament.Name = "DGmedicament";
            this.DGmedicament.Size = new System.Drawing.Size(724, 597);
            this.DGmedicament.TabIndex = 0;
            this.DGmedicament.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGmedicament_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(600, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "Les médicaments";
            // 
            // btn_ModifMedoc
            // 
            this.btn_ModifMedoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ModifMedoc.Location = new System.Drawing.Point(761, 77);
            this.btn_ModifMedoc.Name = "btn_ModifMedoc";
            this.btn_ModifMedoc.Size = new System.Drawing.Size(560, 47);
            this.btn_ModifMedoc.TabIndex = 2;
            this.btn_ModifMedoc.Text = "Modifier le Médicament sélectionné";
            this.btn_ModifMedoc.UseVisualStyleBackColor = true;
            this.btn_ModifMedoc.Click += new System.EventHandler(this.btn_ModifMedoc_Click);
            // 
            // GBmedoc
            // 
            this.GBmedoc.Controls.Add(this.ListFamille);
            this.GBmedoc.Controls.Add(this.button1);
            this.GBmedoc.Controls.Add(this.label6);
            this.GBmedoc.Controls.Add(this.Rtx_CIMedoc);
            this.GBmedoc.Controls.Add(this.label5);
            this.GBmedoc.Controls.Add(this.Rtx_EffetMedoc);
            this.GBmedoc.Controls.Add(this.label4);
            this.GBmedoc.Controls.Add(this.Rtx_CompoMedoc);
            this.GBmedoc.Controls.Add(this.label3);
            this.GBmedoc.Controls.Add(this.Tx_NomMedoc);
            this.GBmedoc.Controls.Add(this.label2);
            this.GBmedoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GBmedoc.Location = new System.Drawing.Point(761, 130);
            this.GBmedoc.Name = "GBmedoc";
            this.GBmedoc.Size = new System.Drawing.Size(560, 544);
            this.GBmedoc.TabIndex = 3;
            this.GBmedoc.TabStop = false;
            this.GBmedoc.Text = "Modifier un médicament";
            this.GBmedoc.Visible = false;
            // 
            // ListFamille
            // 
            this.ListFamille.FormattingEnabled = true;
            this.ListFamille.Location = new System.Drawing.Point(18, 431);
            this.ListFamille.Name = "ListFamille";
            this.ListFamille.Size = new System.Drawing.Size(521, 21);
            this.ListFamille.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(197, 481);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 41);
            this.button1.TabIndex = 10;
            this.button1.Text = "Confirmer";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 399);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "Famille : ";
            // 
            // Rtx_CIMedoc
            // 
            this.Rtx_CIMedoc.Location = new System.Drawing.Point(19, 341);
            this.Rtx_CIMedoc.Name = "Rtx_CIMedoc";
            this.Rtx_CIMedoc.Size = new System.Drawing.Size(520, 40);
            this.Rtx_CIMedoc.TabIndex = 7;
            this.Rtx_CIMedoc.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(19, 305);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Contre Indiction : ";
            // 
            // Rtx_EffetMedoc
            // 
            this.Rtx_EffetMedoc.Location = new System.Drawing.Point(18, 235);
            this.Rtx_EffetMedoc.Name = "Rtx_EffetMedoc";
            this.Rtx_EffetMedoc.Size = new System.Drawing.Size(521, 56);
            this.Rtx_EffetMedoc.TabIndex = 5;
            this.Rtx_EffetMedoc.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Effet(s) :";
            // 
            // Rtx_CompoMedoc
            // 
            this.Rtx_CompoMedoc.Location = new System.Drawing.Point(18, 127);
            this.Rtx_CompoMedoc.Name = "Rtx_CompoMedoc";
            this.Rtx_CompoMedoc.Size = new System.Drawing.Size(521, 60);
            this.Rtx_CompoMedoc.TabIndex = 3;
            this.Rtx_CompoMedoc.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Composition : ";
            // 
            // Tx_NomMedoc
            // 
            this.Tx_NomMedoc.Location = new System.Drawing.Point(19, 68);
            this.Tx_NomMedoc.Name = "Tx_NomMedoc";
            this.Tx_NomMedoc.Size = new System.Drawing.Size(520, 20);
            this.Tx_NomMedoc.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(295, 20);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nom Commerciale du médicament : ";
            // 
            // Id
            // 
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.Visible = false;
            // 
            // nom
            // 
            this.nom.HeaderText = "Nom";
            this.nom.Name = "nom";
            // 
            // composition
            // 
            this.composition.HeaderText = "Composition";
            this.composition.Name = "composition";
            // 
            // effet
            // 
            this.effet.HeaderText = "Effet";
            this.effet.Name = "effet";
            // 
            // contreIndic
            // 
            this.contreIndic.HeaderText = "Contre Indication";
            this.contreIndic.Name = "contreIndic";
            // 
            // idfam
            // 
            this.idfam.HeaderText = "Famille";
            this.idfam.Name = "idfam";
            this.idfam.Visible = false;
            // 
            // LibFamille
            // 
            this.LibFamille.HeaderText = "Famille";
            this.LibFamille.Name = "LibFamille";
            // 
            // FormMedicament
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 686);
            this.Controls.Add(this.GBmedoc);
            this.Controls.Add(this.btn_ModifMedoc);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DGmedicament);
            this.Name = "FormMedicament";
            this.Text = "Liste des medicaments";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMedicament_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGmedicament)).EndInit();
            this.GBmedoc.ResumeLayout(false);
            this.GBmedoc.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGmedicament;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_ModifMedoc;
        private System.Windows.Forms.GroupBox GBmedoc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox Rtx_CIMedoc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox Rtx_EffetMedoc;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox Rtx_CompoMedoc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Tx_NomMedoc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox ListFamille;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn nom;
        private System.Windows.Forms.DataGridViewTextBoxColumn composition;
        private System.Windows.Forms.DataGridViewTextBoxColumn effet;
        private System.Windows.Forms.DataGridViewTextBoxColumn contreIndic;
        private System.Windows.Forms.DataGridViewTextBoxColumn idfam;
        private System.Windows.Forms.DataGridViewTextBoxColumn LibFamille;
    }
}