﻿namespace GSB_CS
{
    partial class FormMedecinDelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gb_comfirmSupp = new System.Windows.Forms.GroupBox();
            this.cb_no = new System.Windows.Forms.CheckBox();
            this.cb_yes = new System.Windows.Forms.CheckBox();
            this.btn_ConfirmSupp = new System.Windows.Forms.Button();
            this.list_Medecin = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gb_comfirmSupp.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_comfirmSupp
            // 
            this.gb_comfirmSupp.Controls.Add(this.cb_no);
            this.gb_comfirmSupp.Controls.Add(this.cb_yes);
            this.gb_comfirmSupp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_comfirmSupp.Location = new System.Drawing.Point(372, 291);
            this.gb_comfirmSupp.Name = "gb_comfirmSupp";
            this.gb_comfirmSupp.Size = new System.Drawing.Size(572, 175);
            this.gb_comfirmSupp.TabIndex = 1;
            this.gb_comfirmSupp.TabStop = false;
            this.gb_comfirmSupp.Text = "Êtes-vous sur de vouloir Supprimer ?  ";
            this.gb_comfirmSupp.Visible = false;
            // 
            // cb_no
            // 
            this.cb_no.AutoSize = true;
            this.cb_no.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_no.Location = new System.Drawing.Point(353, 64);
            this.cb_no.Name = "cb_no";
            this.cb_no.Size = new System.Drawing.Size(181, 24);
            this.cb_no.TabIndex = 1;
            this.cb_no.Text = "Ne supprimez pas !";
            this.cb_no.UseVisualStyleBackColor = true;
            // 
            // cb_yes
            // 
            this.cb_yes.AutoSize = true;
            this.cb_yes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_yes.Location = new System.Drawing.Point(26, 64);
            this.cb_yes.Name = "cb_yes";
            this.cb_yes.Size = new System.Drawing.Size(230, 24);
            this.cb_yes.TabIndex = 0;
            this.cb_yes.Text = "Vous pouvez supprimer ! ";
            this.cb_yes.UseVisualStyleBackColor = true;
            // 
            // btn_ConfirmSupp
            // 
            this.btn_ConfirmSupp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ConfirmSupp.Location = new System.Drawing.Point(527, 539);
            this.btn_ConfirmSupp.Name = "btn_ConfirmSupp";
            this.btn_ConfirmSupp.Size = new System.Drawing.Size(301, 53);
            this.btn_ConfirmSupp.TabIndex = 2;
            this.btn_ConfirmSupp.Text = "Confirmer ";
            this.btn_ConfirmSupp.UseVisualStyleBackColor = true;
            this.btn_ConfirmSupp.Click += new System.EventHandler(this.btn_ConfirmSupp_Click);
            // 
            // list_Medecin
            // 
            this.list_Medecin.FormattingEnabled = true;
            this.list_Medecin.Location = new System.Drawing.Point(269, 154);
            this.list_Medecin.Name = "list_Medecin";
            this.list_Medecin.Size = new System.Drawing.Size(792, 21);
            this.list_Medecin.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(553, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Supprimer Médecin ";
            // 
            // FormMedecinDelete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 686);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.list_Medecin);
            this.Controls.Add(this.btn_ConfirmSupp);
            this.Controls.Add(this.gb_comfirmSupp);
            this.Name = "FormMedecinDelete";
            this.Text = "Supprimer un médecin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMedecinDelete_Load);
            this.gb_comfirmSupp.ResumeLayout(false);
            this.gb_comfirmSupp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox gb_comfirmSupp;
        private System.Windows.Forms.CheckBox cb_no;
        private System.Windows.Forms.CheckBox cb_yes;
        private System.Windows.Forms.Button btn_ConfirmSupp;
        private System.Windows.Forms.ComboBox list_Medecin;
        private System.Windows.Forms.Label label1;
    }
}