﻿
namespace GSB_CS
{
    partial class FormOffrir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cb_Rapport = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cb_Medi = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_Quantite = new System.Windows.Forms.TextBox();
            this.OffreAdd = new System.Windows.Forms.Button();
            this.DGV_Offrir = new System.Windows.Forms.DataGridView();
            this.NRapport = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IdMedi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomMedi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Offrir)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Selectionner un rapport :";
            // 
            // cb_Rapport
            // 
            this.cb_Rapport.FormattingEnabled = true;
            this.cb_Rapport.Location = new System.Drawing.Point(65, 101);
            this.cb_Rapport.Name = "cb_Rapport";
            this.cb_Rapport.Size = new System.Drawing.Size(269, 21);
            this.cb_Rapport.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(428, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(211, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Selectionner un médicament :";
            // 
            // cb_Medi
            // 
            this.cb_Medi.FormattingEnabled = true;
            this.cb_Medi.Location = new System.Drawing.Point(454, 101);
            this.cb_Medi.Name = "cb_Medi";
            this.cb_Medi.Size = new System.Drawing.Size(218, 21);
            this.cb_Medi.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Ajouter une quantité :";
            // 
            // tb_Quantite
            // 
            this.tb_Quantite.Location = new System.Drawing.Point(65, 198);
            this.tb_Quantite.Name = "tb_Quantite";
            this.tb_Quantite.Size = new System.Drawing.Size(269, 20);
            this.tb_Quantite.TabIndex = 5;
            // 
            // OffreAdd
            // 
            this.OffreAdd.Location = new System.Drawing.Point(454, 163);
            this.OffreAdd.Name = "OffreAdd";
            this.OffreAdd.Size = new System.Drawing.Size(218, 55);
            this.OffreAdd.TabIndex = 6;
            this.OffreAdd.Text = "Ajouter";
            this.OffreAdd.UseVisualStyleBackColor = true;
            this.OffreAdd.Click += new System.EventHandler(this.OffreAdd_Click);
            // 
            // DGV_Offrir
            // 
            this.DGV_Offrir.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Offrir.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NRapport,
            this.IdMedi,
            this.nomMedi,
            this.Quantite});
            this.DGV_Offrir.Location = new System.Drawing.Point(33, 254);
            this.DGV_Offrir.Name = "DGV_Offrir";
            this.DGV_Offrir.Size = new System.Drawing.Size(698, 142);
            this.DGV_Offrir.TabIndex = 7;
            // 
            // NRapport
            // 
            this.NRapport.HeaderText = "N°Rapport";
            this.NRapport.Name = "NRapport";
            // 
            // IdMedi
            // 
            this.IdMedi.HeaderText = "Idmedi";
            this.IdMedi.Name = "IdMedi";
            this.IdMedi.Visible = false;
            // 
            // nomMedi
            // 
            this.nomMedi.HeaderText = "Nom du médicament ";
            this.nomMedi.Name = "nomMedi";
            // 
            // Quantite
            // 
            this.Quantite.HeaderText = "Quantité";
            this.Quantite.Name = "Quantite";
            // 
            // FormOffrir
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.DGV_Offrir);
            this.Controls.Add(this.OffreAdd);
            this.Controls.Add(this.tb_Quantite);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cb_Medi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cb_Rapport);
            this.Controls.Add(this.label1);
            this.Name = "FormOffrir";
            this.Text = "FormOffrir";
            this.Load += new System.EventHandler(this.FormOffrir_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Offrir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_Rapport;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cb_Medi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_Quantite;
        private System.Windows.Forms.Button OffreAdd;
        private System.Windows.Forms.DataGridView DGV_Offrir;
        private System.Windows.Forms.DataGridViewTextBoxColumn NRapport;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdMedi;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomMedi;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantite;
    }
}