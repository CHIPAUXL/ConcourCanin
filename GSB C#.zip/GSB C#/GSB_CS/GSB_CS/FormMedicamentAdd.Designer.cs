﻿namespace GSB_CS
{
    partial class FormMedicamentAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Tx_NomMedoc = new System.Windows.Forms.TextBox();
            this.rtx_CompoMedoc = new System.Windows.Forms.RichTextBox();
            this.rtx_EffetMedoc = new System.Windows.Forms.RichTextBox();
            this.rtx_CIMedoc = new System.Windows.Forms.RichTextBox();
            this.btn_ConfirmAjoutMedoc = new System.Windows.Forms.Button();
            this.list_FamilleMedoc = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(526, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(325, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ajout de Médicament. ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(57, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Composition : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(57, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(277, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nom commercial du Médicament :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(57, 295);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Effet(s) : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(41, 384);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(148, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Contre Incation : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(57, 477);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "Famille : ";
            // 
            // Tx_NomMedoc
            // 
            this.Tx_NomMedoc.Location = new System.Drawing.Point(357, 126);
            this.Tx_NomMedoc.Name = "Tx_NomMedoc";
            this.Tx_NomMedoc.Size = new System.Drawing.Size(917, 20);
            this.Tx_NomMedoc.TabIndex = 7;
            // 
            // rtx_CompoMedoc
            // 
            this.rtx_CompoMedoc.Location = new System.Drawing.Point(195, 185);
            this.rtx_CompoMedoc.Name = "rtx_CompoMedoc";
            this.rtx_CompoMedoc.Size = new System.Drawing.Size(1079, 91);
            this.rtx_CompoMedoc.TabIndex = 8;
            this.rtx_CompoMedoc.Text = "";
            // 
            // rtx_EffetMedoc
            // 
            this.rtx_EffetMedoc.Location = new System.Drawing.Point(195, 295);
            this.rtx_EffetMedoc.Name = "rtx_EffetMedoc";
            this.rtx_EffetMedoc.Size = new System.Drawing.Size(1079, 63);
            this.rtx_EffetMedoc.TabIndex = 9;
            this.rtx_EffetMedoc.Text = "";
            // 
            // rtx_CIMedoc
            // 
            this.rtx_CIMedoc.Location = new System.Drawing.Point(195, 386);
            this.rtx_CIMedoc.Name = "rtx_CIMedoc";
            this.rtx_CIMedoc.Size = new System.Drawing.Size(1079, 63);
            this.rtx_CIMedoc.TabIndex = 10;
            this.rtx_CIMedoc.Text = "";
            // 
            // btn_ConfirmAjoutMedoc
            // 
            this.btn_ConfirmAjoutMedoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ConfirmAjoutMedoc.Location = new System.Drawing.Point(532, 558);
            this.btn_ConfirmAjoutMedoc.Name = "btn_ConfirmAjoutMedoc";
            this.btn_ConfirmAjoutMedoc.Size = new System.Drawing.Size(264, 49);
            this.btn_ConfirmAjoutMedoc.TabIndex = 12;
            this.btn_ConfirmAjoutMedoc.Text = "Confirmer ";
            this.btn_ConfirmAjoutMedoc.UseVisualStyleBackColor = true;
            this.btn_ConfirmAjoutMedoc.Click += new System.EventHandler(this.btn_ConfirmAjoutMedoc_Click);
            // 
            // list_FamilleMedoc
            // 
            this.list_FamilleMedoc.FormattingEnabled = true;
            this.list_FamilleMedoc.Location = new System.Drawing.Point(194, 475);
            this.list_FamilleMedoc.Name = "list_FamilleMedoc";
            this.list_FamilleMedoc.Size = new System.Drawing.Size(1080, 21);
            this.list_FamilleMedoc.TabIndex = 13;
            // 
            // FormMedicamentAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 686);
            this.Controls.Add(this.list_FamilleMedoc);
            this.Controls.Add(this.btn_ConfirmAjoutMedoc);
            this.Controls.Add(this.rtx_CIMedoc);
            this.Controls.Add(this.rtx_EffetMedoc);
            this.Controls.Add(this.rtx_CompoMedoc);
            this.Controls.Add(this.Tx_NomMedoc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormMedicamentAdd";
            this.Text = "Ajouter un médicament";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMedicamentAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Tx_NomMedoc;
        private System.Windows.Forms.RichTextBox rtx_CompoMedoc;
        private System.Windows.Forms.RichTextBox rtx_EffetMedoc;
        private System.Windows.Forms.RichTextBox rtx_CIMedoc;
        private System.Windows.Forms.Button btn_ConfirmAjoutMedoc;
        private System.Windows.Forms.ComboBox list_FamilleMedoc;
    }
}