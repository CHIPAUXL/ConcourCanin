﻿namespace GSB_CS
{
    partial class FormMedecinAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Tx_NomMedecin = new System.Windows.Forms.TextBox();
            this.Tx_PrenomMedecin = new System.Windows.Forms.TextBox();
            this.Tx_AdrMedecin = new System.Windows.Forms.TextBox();
            this.Tx_CpMedecin = new System.Windows.Forms.TextBox();
            this.Tx_TelMedecin = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.listSpe = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(587, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ajout de Medecin. ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(84, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nom du Médecin :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(84, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(177, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Prénom du Médecin :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(74, 259);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(187, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Adresse du Médecin : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(74, 381);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(200, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Numéro de Telephone : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(74, 323);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(111, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Code Postal ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(74, 444);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(195, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Spécialité du Médecin :";
            // 
            // Tx_NomMedecin
            // 
            this.Tx_NomMedecin.Location = new System.Drawing.Point(300, 143);
            this.Tx_NomMedecin.Name = "Tx_NomMedecin";
            this.Tx_NomMedecin.Size = new System.Drawing.Size(942, 20);
            this.Tx_NomMedecin.TabIndex = 7;
            // 
            // Tx_PrenomMedecin
            // 
            this.Tx_PrenomMedecin.Location = new System.Drawing.Point(300, 201);
            this.Tx_PrenomMedecin.Name = "Tx_PrenomMedecin";
            this.Tx_PrenomMedecin.Size = new System.Drawing.Size(942, 20);
            this.Tx_PrenomMedecin.TabIndex = 8;
            // 
            // Tx_AdrMedecin
            // 
            this.Tx_AdrMedecin.Location = new System.Drawing.Point(300, 261);
            this.Tx_AdrMedecin.Name = "Tx_AdrMedecin";
            this.Tx_AdrMedecin.Size = new System.Drawing.Size(942, 20);
            this.Tx_AdrMedecin.TabIndex = 9;
            // 
            // Tx_CpMedecin
            // 
            this.Tx_CpMedecin.Location = new System.Drawing.Point(300, 325);
            this.Tx_CpMedecin.MaxLength = 5;
            this.Tx_CpMedecin.Name = "Tx_CpMedecin";
            this.Tx_CpMedecin.Size = new System.Drawing.Size(942, 20);
            this.Tx_CpMedecin.TabIndex = 10;
            // 
            // Tx_TelMedecin
            // 
            this.Tx_TelMedecin.Location = new System.Drawing.Point(300, 381);
            this.Tx_TelMedecin.Name = "Tx_TelMedecin";
            this.Tx_TelMedecin.Size = new System.Drawing.Size(942, 20);
            this.Tx_TelMedecin.TabIndex = 11;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(555, 511);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(337, 61);
            this.button1.TabIndex = 13;
            this.button1.Text = "Confirmer ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listSpe
            // 
            this.listSpe.FormattingEnabled = true;
            this.listSpe.Location = new System.Drawing.Point(300, 443);
            this.listSpe.Name = "listSpe";
            this.listSpe.Size = new System.Drawing.Size(942, 21);
            this.listSpe.TabIndex = 14;
            // 
            // FormMedecinAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1370, 686);
            this.Controls.Add(this.listSpe);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Tx_TelMedecin);
            this.Controls.Add(this.Tx_CpMedecin);
            this.Controls.Add(this.Tx_AdrMedecin);
            this.Controls.Add(this.Tx_PrenomMedecin);
            this.Controls.Add(this.Tx_NomMedecin);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "FormMedecinAdd";
            this.Text = "Ajouter un médecin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMedecinAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Tx_NomMedecin;
        private System.Windows.Forms.TextBox Tx_PrenomMedecin;
        private System.Windows.Forms.TextBox Tx_AdrMedecin;
        private System.Windows.Forms.TextBox Tx_CpMedecin;
        private System.Windows.Forms.TextBox Tx_TelMedecin;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox listSpe;
    }
}