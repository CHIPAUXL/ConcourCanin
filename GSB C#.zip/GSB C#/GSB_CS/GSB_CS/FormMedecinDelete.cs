﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;

namespace GSB_CS
{
    public partial class FormMedecinDelete : Form
    {
        public FormMedecinDelete()
        {
            InitializeComponent();
        }

        private void LoadListMed()
        {
            List<Medecin> lesMedecin = new List<Medecin>(); // Create Medecin List
            lesMedecin = MedecinPass.GetMedecins(); // Get Medecin from database
            list_Medecin.DisplayMember = "nom"; // Medecin formation that's displayed
            list_Medecin.ValueMember = "id"; //Medecin value
            list_Medecin.DataSource = lesMedecin; // Select where datas came from
        }

        private void FormMedecinDelete_Load(object sender, EventArgs e)
        {
            LoadListMed(); // Load list when form is load
        }

        private void btn_ConfirmSupp_Click(object sender, EventArgs e)
        {
            if(gb_comfirmSupp.Visible == false)
            {
                gb_comfirmSupp.Visible = true;
            }
            else if (cb_yes.Checked == true) // If combobov checked then
            {
                string id = list_Medecin.SelectedValue.ToString(); //Get the Id from list with the ValueMember

                try
                {
                 MedecinPass.DeleteMedecin(id); //Use delete function
                 MessageBox.Show("Le medecin à été supprimer."); // Inform the user
                }
                catch(Exception err)
                {
                    MessageBox.Show("Erreur : " + err);
                }
                LoadListMed(); //Reload Medecin list

            }
        }


    }
}
