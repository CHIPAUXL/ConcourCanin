﻿namespace GSB_CS
{
    partial class FormMedecin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGMedecin = new System.Windows.Forms.DataGridView();
            this.gbMedecinMod = new System.Windows.Forms.GroupBox();
            this.lblMedecinMod = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnConfirmMedecinMod = new System.Windows.Forms.Button();
            this.cpMedecinMod = new System.Windows.Forms.TextBox();
            this.telMedecinMod = new System.Windows.Forms.TextBox();
            this.adresseMedecinMod = new System.Windows.Forms.TextBox();
            this.prenomMedecinMod = new System.Windows.Forms.TextBox();
            this.nomMedecinMod = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.btnMod = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.idMedecin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameMedecin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnomMedecin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addMedecin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telMedecin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.depMédécin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.speMedecin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LibSpé = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.DGMedecin)).BeginInit();
            this.gbMedecinMod.SuspendLayout();
            this.SuspendLayout();
            // 
            // DGMedecin
            // 
            this.DGMedecin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGMedecin.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idMedecin,
            this.nameMedecin,
            this.pnomMedecin,
            this.addMedecin,
            this.telMedecin,
            this.depMédécin,
            this.speMedecin,
            this.LibSpé});
            this.DGMedecin.Location = new System.Drawing.Point(12, 71);
            this.DGMedecin.Name = "DGMedecin";
            this.DGMedecin.ReadOnly = true;
            this.DGMedecin.Size = new System.Drawing.Size(648, 614);
            this.DGMedecin.TabIndex = 0;
            this.DGMedecin.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGMedecin_CellContentDoubleClick_1);
            // 
            // gbMedecinMod
            // 
            this.gbMedecinMod.AutoSize = true;
            this.gbMedecinMod.Controls.Add(this.lblMedecinMod);
            this.gbMedecinMod.Controls.Add(this.label1);
            this.gbMedecinMod.Controls.Add(this.btnConfirmMedecinMod);
            this.gbMedecinMod.Controls.Add(this.cpMedecinMod);
            this.gbMedecinMod.Controls.Add(this.telMedecinMod);
            this.gbMedecinMod.Controls.Add(this.adresseMedecinMod);
            this.gbMedecinMod.Controls.Add(this.prenomMedecinMod);
            this.gbMedecinMod.Controls.Add(this.nomMedecinMod);
            this.gbMedecinMod.Controls.Add(this.label11);
            this.gbMedecinMod.Controls.Add(this.label13);
            this.gbMedecinMod.Controls.Add(this.label14);
            this.gbMedecinMod.Controls.Add(this.label15);
            this.gbMedecinMod.Controls.Add(this.label16);
            this.gbMedecinMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbMedecinMod.Location = new System.Drawing.Point(666, 132);
            this.gbMedecinMod.Name = "gbMedecinMod";
            this.gbMedecinMod.Size = new System.Drawing.Size(597, 553);
            this.gbMedecinMod.TabIndex = 23;
            this.gbMedecinMod.TabStop = false;
            this.gbMedecinMod.Text = "Modifier un médecin.";
            this.gbMedecinMod.Visible = false;
            // 
            // lblMedecinMod
            // 
            this.lblMedecinMod.FormattingEnabled = true;
            this.lblMedecinMod.Location = new System.Drawing.Point(177, 435);
            this.lblMedecinMod.Name = "lblMedecinMod";
            this.lblMedecinMod.Size = new System.Drawing.Size(379, 24);
            this.lblMedecinMod.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 432);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 24);
            this.label1.TabIndex = 22;
            this.label1.Text = "Spécialité :";
            // 
            // btnConfirmMedecinMod
            // 
            this.btnConfirmMedecinMod.Location = new System.Drawing.Point(179, 488);
            this.btnConfirmMedecinMod.Name = "btnConfirmMedecinMod";
            this.btnConfirmMedecinMod.Size = new System.Drawing.Size(229, 44);
            this.btnConfirmMedecinMod.TabIndex = 21;
            this.btnConfirmMedecinMod.Text = "Comfirmer";
            this.btnConfirmMedecinMod.UseVisualStyleBackColor = true;
            this.btnConfirmMedecinMod.Click += new System.EventHandler(this.btnConfirmMedecinMod_Click);
            // 
            // cpMedecinMod
            // 
            this.cpMedecinMod.Location = new System.Drawing.Point(179, 353);
            this.cpMedecinMod.MaxLength = 5;
            this.cpMedecinMod.Name = "cpMedecinMod";
            this.cpMedecinMod.Size = new System.Drawing.Size(377, 22);
            this.cpMedecinMod.TabIndex = 18;
            // 
            // telMedecinMod
            // 
            this.telMedecinMod.Location = new System.Drawing.Point(179, 198);
            this.telMedecinMod.Name = "telMedecinMod";
            this.telMedecinMod.Size = new System.Drawing.Size(377, 22);
            this.telMedecinMod.TabIndex = 16;
            // 
            // adresseMedecinMod
            // 
            this.adresseMedecinMod.Location = new System.Drawing.Point(179, 271);
            this.adresseMedecinMod.Name = "adresseMedecinMod";
            this.adresseMedecinMod.Size = new System.Drawing.Size(377, 22);
            this.adresseMedecinMod.TabIndex = 15;
            // 
            // prenomMedecinMod
            // 
            this.prenomMedecinMod.Location = new System.Drawing.Point(177, 119);
            this.prenomMedecinMod.Name = "prenomMedecinMod";
            this.prenomMedecinMod.Size = new System.Drawing.Size(379, 22);
            this.prenomMedecinMod.TabIndex = 14;
            // 
            // nomMedecinMod
            // 
            this.nomMedecinMod.Location = new System.Drawing.Point(177, 62);
            this.nomMedecinMod.Name = "nomMedecinMod";
            this.nomMedecinMod.Size = new System.Drawing.Size(379, 22);
            this.nomMedecinMod.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(27, 350);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(147, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "Département : ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(27, 195);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(124, 24);
            this.label13.TabIndex = 8;
            this.label13.Text = "Téléphone :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(30, 268);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(105, 24);
            this.label14.TabIndex = 7;
            this.label14.Text = "Adresse : ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(27, 116);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 24);
            this.label15.TabIndex = 6;
            this.label15.Text = "Prénom :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(30, 62);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(66, 24);
            this.label16.TabIndex = 5;
            this.label16.Text = "Nom :";
            // 
            // btnMod
            // 
            this.btnMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMod.Location = new System.Drawing.Point(666, 71);
            this.btnMod.Name = "btnMod";
            this.btnMod.Size = new System.Drawing.Size(597, 55);
            this.btnMod.TabIndex = 24;
            this.btnMod.Text = "Modifier le Médecin sélectionné.";
            this.btnMod.UseVisualStyleBackColor = true;
            this.btnMod.Click += new System.EventHandler(this.btnMod_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(563, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 33);
            this.label8.TabIndex = 27;
            this.label8.Text = "Les médecins";
            // 
            // idMedecin
            // 
            this.idMedecin.HeaderText = "ID";
            this.idMedecin.Name = "idMedecin";
            this.idMedecin.ReadOnly = true;
            this.idMedecin.Visible = false;
            // 
            // nameMedecin
            // 
            this.nameMedecin.HeaderText = "Nom";
            this.nameMedecin.Name = "nameMedecin";
            this.nameMedecin.ReadOnly = true;
            // 
            // pnomMedecin
            // 
            this.pnomMedecin.HeaderText = "Prenom";
            this.pnomMedecin.Name = "pnomMedecin";
            this.pnomMedecin.ReadOnly = true;
            // 
            // addMedecin
            // 
            this.addMedecin.HeaderText = "Adresse";
            this.addMedecin.Name = "addMedecin";
            this.addMedecin.ReadOnly = true;
            // 
            // telMedecin
            // 
            this.telMedecin.HeaderText = "Téléphone";
            this.telMedecin.Name = "telMedecin";
            this.telMedecin.ReadOnly = true;
            // 
            // depMédécin
            // 
            this.depMédécin.HeaderText = "Département";
            this.depMédécin.Name = "depMédécin";
            this.depMédécin.ReadOnly = true;
            // 
            // speMedecin
            // 
            this.speMedecin.HeaderText = "IdSpé";
            this.speMedecin.Name = "speMedecin";
            this.speMedecin.ReadOnly = true;
            this.speMedecin.Visible = false;
            // 
            // LibSpé
            // 
            this.LibSpé.HeaderText = "Spécialité";
            this.LibSpé.Name = "LibSpé";
            this.LibSpé.ReadOnly = true;
            // 
            // FormMedecin
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1284, 697);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnMod);
            this.Controls.Add(this.gbMedecinMod);
            this.Controls.Add(this.DGMedecin);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Location = new System.Drawing.Point(850, 375);
            this.Name = "FormMedecin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Liste médecins";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormMedecin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGMedecin)).EndInit();
            this.gbMedecinMod.ResumeLayout(false);
            this.gbMedecinMod.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGMedecin;
        private System.Windows.Forms.GroupBox gbMedecinMod;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnConfirmMedecinMod;
        private System.Windows.Forms.TextBox cpMedecinMod;
        private System.Windows.Forms.TextBox telMedecinMod;
        private System.Windows.Forms.TextBox adresseMedecinMod;
        private System.Windows.Forms.TextBox prenomMedecinMod;
        private System.Windows.Forms.TextBox nomMedecinMod;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnMod;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox lblMedecinMod;
        private System.Windows.Forms.DataGridViewTextBoxColumn idMedecin;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameMedecin;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnomMedecin;
        private System.Windows.Forms.DataGridViewTextBoxColumn addMedecin;
        private System.Windows.Forms.DataGridViewTextBoxColumn telMedecin;
        private System.Windows.Forms.DataGridViewTextBoxColumn depMédécin;
        private System.Windows.Forms.DataGridViewTextBoxColumn speMedecin;
        private System.Windows.Forms.DataGridViewTextBoxColumn LibSpé;
    }
}