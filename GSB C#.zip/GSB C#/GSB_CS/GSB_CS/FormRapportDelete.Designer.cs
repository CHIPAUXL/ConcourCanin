﻿namespace GSB_CS
{
    partial class FormRapportDelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_ConfirmSupp = new System.Windows.Forms.Button();
            this.gb_comfirmSupp = new System.Windows.Forms.GroupBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.CB_yes = new System.Windows.Forms.CheckBox();
            this.list_Rapport = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gb_comfirmSupp.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_ConfirmSupp
            // 
            this.btn_ConfirmSupp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ConfirmSupp.Location = new System.Drawing.Point(512, 572);
            this.btn_ConfirmSupp.Name = "btn_ConfirmSupp";
            this.btn_ConfirmSupp.Size = new System.Drawing.Size(436, 58);
            this.btn_ConfirmSupp.TabIndex = 5;
            this.btn_ConfirmSupp.Text = "Confirmer ";
            this.btn_ConfirmSupp.UseVisualStyleBackColor = true;
            this.btn_ConfirmSupp.Click += new System.EventHandler(this.btn_ConfirmSupp_Click);
            // 
            // gb_comfirmSupp
            // 
            this.gb_comfirmSupp.Controls.Add(this.checkBox2);
            this.gb_comfirmSupp.Controls.Add(this.CB_yes);
            this.gb_comfirmSupp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_comfirmSupp.Location = new System.Drawing.Point(423, 350);
            this.gb_comfirmSupp.Name = "gb_comfirmSupp";
            this.gb_comfirmSupp.Size = new System.Drawing.Size(633, 163);
            this.gb_comfirmSupp.TabIndex = 4;
            this.gb_comfirmSupp.TabStop = false;
            this.gb_comfirmSupp.Text = "Êtes-vous sur de vouloir Supprimer ?  ";
            this.gb_comfirmSupp.Visible = false;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(394, 64);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(181, 24);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Ne supprimez pas !";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // CB_yes
            // 
            this.CB_yes.AutoSize = true;
            this.CB_yes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CB_yes.Location = new System.Drawing.Point(49, 64);
            this.CB_yes.Name = "CB_yes";
            this.CB_yes.Size = new System.Drawing.Size(230, 24);
            this.CB_yes.TabIndex = 0;
            this.CB_yes.Text = "Vous pouvez supprimer ! ";
            this.CB_yes.UseVisualStyleBackColor = true;
            // 
            // list_Rapport
            // 
            this.list_Rapport.FormattingEnabled = true;
            this.list_Rapport.Location = new System.Drawing.Point(312, 254);
            this.list_Rapport.Name = "list_Rapport";
            this.list_Rapport.Size = new System.Drawing.Size(818, 21);
            this.list_Rapport.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(616, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "Supprimer Rapport";
            // 
            // FormRapportDelete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 686);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.list_Rapport);
            this.Controls.Add(this.btn_ConfirmSupp);
            this.Controls.Add(this.gb_comfirmSupp);
            this.Name = "FormRapportDelete";
            this.Text = "Supprimer un rapport";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormRapportDelete_Load);
            this.gb_comfirmSupp.ResumeLayout(false);
            this.gb_comfirmSupp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_ConfirmSupp;
        private System.Windows.Forms.GroupBox gb_comfirmSupp;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox CB_yes;
        private System.Windows.Forms.ComboBox list_Rapport;
        private System.Windows.Forms.Label label1;
    }
}