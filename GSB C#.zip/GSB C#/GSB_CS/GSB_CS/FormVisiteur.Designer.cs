﻿namespace GSB_CS
{
    partial class FormVisiteur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGVisiteur = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomVisiteur = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnomVisiteur = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loginVis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mdpVi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adrssVi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityVi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateEmbauche = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnMod = new System.Windows.Forms.Button();
            this.gbVisiteurMod = new System.Windows.Forms.GroupBox();
            this.Dt_Embauche = new System.Windows.Forms.DateTimePicker();
            this.btnConfirmMod = new System.Windows.Forms.Button();
            this.villeVisiteurMod = new System.Windows.Forms.TextBox();
            this.cpVisiteurMod = new System.Windows.Forms.TextBox();
            this.adresseVisiteurMod = new System.Windows.Forms.TextBox();
            this.mdpVisiteurMod = new System.Windows.Forms.TextBox();
            this.loginVisiteurMod = new System.Windows.Forms.TextBox();
            this.prenomVisiteurMod = new System.Windows.Forms.TextBox();
            this.nomVisiteurMod = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DGVisiteur)).BeginInit();
            this.gbVisiteurMod.SuspendLayout();
            this.SuspendLayout();
            // 
            // DGVisiteur
            // 
            this.DGVisiteur.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVisiteur.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.nomVisiteur,
            this.pnomVisiteur,
            this.loginVis,
            this.mdpVi,
            this.adrssVi,
            this.Cp,
            this.cityVi,
            this.dateEmbauche});
            this.DGVisiteur.Location = new System.Drawing.Point(12, 76);
            this.DGVisiteur.Name = "DGVisiteur";
            this.DGVisiteur.Size = new System.Drawing.Size(744, 570);
            this.DGVisiteur.TabIndex = 0;
            this.DGVisiteur.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVisiteur_CellContentClick);
            // 
            // id
            // 
            this.id.HeaderText = "ID";
            this.id.Name = "id";
            this.id.Visible = false;
            // 
            // nomVisiteur
            // 
            this.nomVisiteur.HeaderText = "Nom";
            this.nomVisiteur.Name = "nomVisiteur";
            this.nomVisiteur.ReadOnly = true;
            // 
            // pnomVisiteur
            // 
            this.pnomVisiteur.HeaderText = "Prenom";
            this.pnomVisiteur.Name = "pnomVisiteur";
            this.pnomVisiteur.ReadOnly = true;
            // 
            // loginVis
            // 
            this.loginVis.HeaderText = "Login";
            this.loginVis.Name = "loginVis";
            this.loginVis.ReadOnly = true;
            // 
            // mdpVi
            // 
            this.mdpVi.HeaderText = "Mot de passe";
            this.mdpVi.Name = "mdpVi";
            this.mdpVi.ReadOnly = true;
            this.mdpVi.Visible = false;
            // 
            // adrssVi
            // 
            this.adrssVi.HeaderText = "Adresse";
            this.adrssVi.Name = "adrssVi";
            this.adrssVi.ReadOnly = true;
            // 
            // Cp
            // 
            this.Cp.HeaderText = "Code postal";
            this.Cp.Name = "Cp";
            this.Cp.ReadOnly = true;
            // 
            // cityVi
            // 
            this.cityVi.HeaderText = "Ville";
            this.cityVi.Name = "cityVi";
            this.cityVi.ReadOnly = true;
            // 
            // dateEmbauche
            // 
            this.dateEmbauche.HeaderText = "Date Embauche";
            this.dateEmbauche.Name = "dateEmbauche";
            this.dateEmbauche.ReadOnly = true;
            // 
            // btnMod
            // 
            this.btnMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMod.Location = new System.Drawing.Point(772, 76);
            this.btnMod.Name = "btnMod";
            this.btnMod.Size = new System.Drawing.Size(571, 48);
            this.btnMod.TabIndex = 2;
            this.btnMod.Text = "Modifier le Visiteur Sélectionné ";
            this.btnMod.UseVisualStyleBackColor = true;
            this.btnMod.Click += new System.EventHandler(this.btnMod_Click);
            // 
            // gbVisiteurMod
            // 
            this.gbVisiteurMod.Controls.Add(this.Dt_Embauche);
            this.gbVisiteurMod.Controls.Add(this.btnConfirmMod);
            this.gbVisiteurMod.Controls.Add(this.villeVisiteurMod);
            this.gbVisiteurMod.Controls.Add(this.cpVisiteurMod);
            this.gbVisiteurMod.Controls.Add(this.adresseVisiteurMod);
            this.gbVisiteurMod.Controls.Add(this.mdpVisiteurMod);
            this.gbVisiteurMod.Controls.Add(this.loginVisiteurMod);
            this.gbVisiteurMod.Controls.Add(this.prenomVisiteurMod);
            this.gbVisiteurMod.Controls.Add(this.nomVisiteurMod);
            this.gbVisiteurMod.Controls.Add(this.label9);
            this.gbVisiteurMod.Controls.Add(this.label10);
            this.gbVisiteurMod.Controls.Add(this.label11);
            this.gbVisiteurMod.Controls.Add(this.label12);
            this.gbVisiteurMod.Controls.Add(this.label13);
            this.gbVisiteurMod.Controls.Add(this.label14);
            this.gbVisiteurMod.Controls.Add(this.label15);
            this.gbVisiteurMod.Controls.Add(this.label16);
            this.gbVisiteurMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbVisiteurMod.Location = new System.Drawing.Point(772, 130);
            this.gbVisiteurMod.Name = "gbVisiteurMod";
            this.gbVisiteurMod.Size = new System.Drawing.Size(571, 528);
            this.gbVisiteurMod.TabIndex = 22;
            this.gbVisiteurMod.TabStop = false;
            this.gbVisiteurMod.Text = "Modifier un visiteur.";
            this.gbVisiteurMod.Visible = false;
            // 
            // Dt_Embauche
            // 
            this.Dt_Embauche.Location = new System.Drawing.Point(236, 440);
            this.Dt_Embauche.Name = "Dt_Embauche";
            this.Dt_Embauche.Size = new System.Drawing.Size(281, 22);
            this.Dt_Embauche.TabIndex = 22;
            // 
            // btnConfirmMod
            // 
            this.btnConfirmMod.Location = new System.Drawing.Point(180, 472);
            this.btnConfirmMod.Name = "btnConfirmMod";
            this.btnConfirmMod.Size = new System.Drawing.Size(229, 44);
            this.btnConfirmMod.TabIndex = 21;
            this.btnConfirmMod.Text = "Confirmer";
            this.btnConfirmMod.UseVisualStyleBackColor = true;
            this.btnConfirmMod.Click += new System.EventHandler(this.btnConfirmMod_Click);
            // 
            // villeVisiteurMod
            // 
            this.villeVisiteurMod.Location = new System.Drawing.Point(102, 406);
            this.villeVisiteurMod.Name = "villeVisiteurMod";
            this.villeVisiteurMod.Size = new System.Drawing.Size(438, 22);
            this.villeVisiteurMod.TabIndex = 19;
            // 
            // cpVisiteurMod
            // 
            this.cpVisiteurMod.Location = new System.Drawing.Point(164, 351);
            this.cpVisiteurMod.MaxLength = 5;
            this.cpVisiteurMod.Name = "cpVisiteurMod";
            this.cpVisiteurMod.Size = new System.Drawing.Size(377, 22);
            this.cpVisiteurMod.TabIndex = 18;
            // 
            // adresseVisiteurMod
            // 
            this.adresseVisiteurMod.Location = new System.Drawing.Point(186, 286);
            this.adresseVisiteurMod.Name = "adresseVisiteurMod";
            this.adresseVisiteurMod.Size = new System.Drawing.Size(356, 22);
            this.adresseVisiteurMod.TabIndex = 17;
            // 
            // mdpVisiteurMod
            // 
            this.mdpVisiteurMod.Location = new System.Drawing.Point(180, 238);
            this.mdpVisiteurMod.Name = "mdpVisiteurMod";
            this.mdpVisiteurMod.ReadOnly = true;
            this.mdpVisiteurMod.Size = new System.Drawing.Size(362, 22);
            this.mdpVisiteurMod.TabIndex = 16;
            this.mdpVisiteurMod.UseSystemPasswordChar = true;
            // 
            // loginVisiteurMod
            // 
            this.loginVisiteurMod.Location = new System.Drawing.Point(106, 176);
            this.loginVisiteurMod.Name = "loginVisiteurMod";
            this.loginVisiteurMod.Size = new System.Drawing.Size(436, 22);
            this.loginVisiteurMod.TabIndex = 15;
            // 
            // prenomVisiteurMod
            // 
            this.prenomVisiteurMod.Location = new System.Drawing.Point(129, 122);
            this.prenomVisiteurMod.Name = "prenomVisiteurMod";
            this.prenomVisiteurMod.Size = new System.Drawing.Size(415, 22);
            this.prenomVisiteurMod.TabIndex = 14;
            // 
            // nomVisiteurMod
            // 
            this.nomVisiteurMod.Location = new System.Drawing.Point(102, 62);
            this.nomVisiteurMod.Name = "nomVisiteurMod";
            this.nomVisiteurMod.Size = new System.Drawing.Size(443, 22);
            this.nomVisiteurMod.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(27, 440);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(192, 24);
            this.label9.TabIndex = 12;
            this.label9.Text = "Date d\'embauche : ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(30, 402);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 24);
            this.label10.TabIndex = 11;
            this.label10.Text = "Ville :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(27, 346);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(139, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "Code postal : ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(27, 283);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(156, 24);
            this.label12.TabIndex = 9;
            this.label12.Text = "Adresse (rue) : ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(27, 233);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(153, 24);
            this.label13.TabIndex = 8;
            this.label13.Text = "Mot de passe : ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(28, 173);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 24);
            this.label14.TabIndex = 7;
            this.label14.Text = "Login : ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(27, 116);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 24);
            this.label15.TabIndex = 6;
            this.label15.Text = "Prénom :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(30, 62);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(66, 24);
            this.label16.TabIndex = 5;
            this.label16.Text = "Nom :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(702, 29);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(192, 33);
            this.label17.TabIndex = 28;
            this.label17.Text = "Les visiteurs";
            // 
            // FormVisiteur
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.gbVisiteurMod);
            this.Controls.Add(this.btnMod);
            this.Controls.Add(this.DGVisiteur);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Location = new System.Drawing.Point(850, 375);
            this.Name = "FormVisiteur";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Liste des visiteurs";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormVisiteur_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGVisiteur)).EndInit();
            this.gbVisiteurMod.ResumeLayout(false);
            this.gbVisiteurMod.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGVisiteur;
        private System.Windows.Forms.Button btnMod;
        private System.Windows.Forms.GroupBox gbVisiteurMod;
        private System.Windows.Forms.Button btnConfirmMod;
        private System.Windows.Forms.TextBox villeVisiteurMod;
        private System.Windows.Forms.TextBox cpVisiteurMod;
        private System.Windows.Forms.TextBox adresseVisiteurMod;
        private System.Windows.Forms.TextBox mdpVisiteurMod;
        private System.Windows.Forms.TextBox loginVisiteurMod;
        private System.Windows.Forms.TextBox prenomVisiteurMod;
        private System.Windows.Forms.TextBox nomVisiteurMod;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomVisiteur;
        private System.Windows.Forms.DataGridViewTextBoxColumn pnomVisiteur;
        private System.Windows.Forms.DataGridViewTextBoxColumn loginVis;
        private System.Windows.Forms.DataGridViewTextBoxColumn mdpVi;
        private System.Windows.Forms.DataGridViewTextBoxColumn adrssVi;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cp;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityVi;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateEmbauche;
        private System.Windows.Forms.DateTimePicker Dt_Embauche;
    }
}