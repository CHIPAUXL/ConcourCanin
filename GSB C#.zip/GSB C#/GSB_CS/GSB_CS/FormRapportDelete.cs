﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;

namespace GSB_CS
{
    public partial class FormRapportDelete : Form
    {
        public FormRapportDelete()
        {
            InitializeComponent();
        }

        private void LoadRapport()
        {
            List<Rapport> lesRapports = new List<Rapport>(); // Create Rapport List
            lesRapports = RapportPass.GetRapports(); // Get Rapport from database

            list_Rapport.DisplayMember = "nom"; // Rapport formation that's displayed
            list_Rapport.ValueMember = "id"; // Rapport value
            list_Rapport.DataSource = lesRapports; // Select where datas came from
        }

        private void FormRapportDelete_Load(object sender, EventArgs e)
        {
            LoadRapport(); //Load datas when loading form
        }

        private void btn_ConfirmSupp_Click(object sender, EventArgs e)
        {
            if (gb_comfirmSupp.Visible == false)
            {
                gb_comfirmSupp.Visible = true;
            }
            else if (CB_yes.Checked == true) // If combobov checked then
            {
                string id = list_Rapport.SelectedValue.ToString(); //Get the Id from list with the ValueMember

                try
                {
                    RapportPass.DeleteRapport(id); //Use delete function
                    MessageBox.Show("Le rapport à été supprimer."); // Inform the user
                }
                catch (Exception err)
                {
                    MessageBox.Show("Erreur : " + err);
                }
                LoadRapport(); //Reload Medecin list

            }
        }
    }
}
