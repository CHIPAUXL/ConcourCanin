﻿namespace GSB_CS
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.motif = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gestionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rapportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listeDesRapportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajouterUnRapportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.suprimerUnRapportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.praticiensToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listeDesPraticiensToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajouterUnPraticienToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supprimerUnPraticienToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visiteursToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listeDesVisiteursToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajouterUnVisiteurToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supprimerUnVisiteurToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.medicamentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listeDesMédicamentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajouterUnMédicamentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.supprimerUnMédicamentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.offreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajouterUneQuantitéToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // date
            // 
            this.date.HeaderText = "Date";
            this.date.Name = "date";
            // 
            // motif
            // 
            this.motif.HeaderText = "Motif";
            this.motif.Name = "motif";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.MdiWindowListItem = this.gestionToolStripMenuItem;
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1127, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gestionToolStripMenuItem
            // 
            this.gestionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rapportsToolStripMenuItem,
            this.praticiensToolStripMenuItem,
            this.visiteursToolStripMenuItem,
            this.medicamentsToolStripMenuItem,
            this.offreToolStripMenuItem});
            this.gestionToolStripMenuItem.Name = "gestionToolStripMenuItem";
            this.gestionToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.gestionToolStripMenuItem.Text = "&Gestion";
            // 
            // rapportsToolStripMenuItem
            // 
            this.rapportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listeDesRapportsToolStripMenuItem,
            this.ajouterUnRapportToolStripMenuItem,
            this.suprimerUnRapportToolStripMenuItem});
            this.rapportsToolStripMenuItem.Name = "rapportsToolStripMenuItem";
            this.rapportsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.rapportsToolStripMenuItem.Text = "&Rapports";
            // 
            // listeDesRapportsToolStripMenuItem
            // 
            this.listeDesRapportsToolStripMenuItem.Name = "listeDesRapportsToolStripMenuItem";
            this.listeDesRapportsToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.listeDesRapportsToolStripMenuItem.Text = "Liste des rapports";
            this.listeDesRapportsToolStripMenuItem.Click += new System.EventHandler(this.ListeDesRapportsToolStripMenuItem_Click);
            // 
            // ajouterUnRapportToolStripMenuItem
            // 
            this.ajouterUnRapportToolStripMenuItem.Name = "ajouterUnRapportToolStripMenuItem";
            this.ajouterUnRapportToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.ajouterUnRapportToolStripMenuItem.Text = "Ajouter un rapport";
            this.ajouterUnRapportToolStripMenuItem.Click += new System.EventHandler(this.AjouterUnRapportToolStripMenuItem_Click);
            // 
            // suprimerUnRapportToolStripMenuItem
            // 
            this.suprimerUnRapportToolStripMenuItem.Name = "suprimerUnRapportToolStripMenuItem";
            this.suprimerUnRapportToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.suprimerUnRapportToolStripMenuItem.Text = "Suprimer un rapport";
            this.suprimerUnRapportToolStripMenuItem.Click += new System.EventHandler(this.SuprimerUnRapportToolStripMenuItem_Click);
            // 
            // praticiensToolStripMenuItem
            // 
            this.praticiensToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listeDesPraticiensToolStripMenuItem,
            this.ajouterUnPraticienToolStripMenuItem,
            this.supprimerUnPraticienToolStripMenuItem});
            this.praticiensToolStripMenuItem.Name = "praticiensToolStripMenuItem";
            this.praticiensToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.praticiensToolStripMenuItem.Text = "&Medecin";
            // 
            // listeDesPraticiensToolStripMenuItem
            // 
            this.listeDesPraticiensToolStripMenuItem.Name = "listeDesPraticiensToolStripMenuItem";
            this.listeDesPraticiensToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.listeDesPraticiensToolStripMenuItem.Text = "Liste des medecins";
            this.listeDesPraticiensToolStripMenuItem.Click += new System.EventHandler(this.ListeDesPraticiensToolStripMenuItem_Click);
            // 
            // ajouterUnPraticienToolStripMenuItem
            // 
            this.ajouterUnPraticienToolStripMenuItem.Name = "ajouterUnPraticienToolStripMenuItem";
            this.ajouterUnPraticienToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.ajouterUnPraticienToolStripMenuItem.Text = "Ajouter un medecin";
            this.ajouterUnPraticienToolStripMenuItem.Click += new System.EventHandler(this.AjouterUnPraticienToolStripMenuItem_Click);
            // 
            // supprimerUnPraticienToolStripMenuItem
            // 
            this.supprimerUnPraticienToolStripMenuItem.Name = "supprimerUnPraticienToolStripMenuItem";
            this.supprimerUnPraticienToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.supprimerUnPraticienToolStripMenuItem.Text = "Supprimer un medecin";
            this.supprimerUnPraticienToolStripMenuItem.Click += new System.EventHandler(this.SupprimerUnPraticienToolStripMenuItem_Click);
            // 
            // visiteursToolStripMenuItem
            // 
            this.visiteursToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listeDesVisiteursToolStripMenuItem,
            this.ajouterUnVisiteurToolStripMenuItem,
            this.supprimerUnVisiteurToolStripMenuItem});
            this.visiteursToolStripMenuItem.Name = "visiteursToolStripMenuItem";
            this.visiteursToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.visiteursToolStripMenuItem.Text = "&Visiteurs";
            // 
            // listeDesVisiteursToolStripMenuItem
            // 
            this.listeDesVisiteursToolStripMenuItem.Name = "listeDesVisiteursToolStripMenuItem";
            this.listeDesVisiteursToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.listeDesVisiteursToolStripMenuItem.Text = "Liste des visiteurs";
            this.listeDesVisiteursToolStripMenuItem.Click += new System.EventHandler(this.ListeDesVisiteursToolStripMenuItem_Click);
            // 
            // ajouterUnVisiteurToolStripMenuItem
            // 
            this.ajouterUnVisiteurToolStripMenuItem.Name = "ajouterUnVisiteurToolStripMenuItem";
            this.ajouterUnVisiteurToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.ajouterUnVisiteurToolStripMenuItem.Text = "Ajouter un visiteur";
            this.ajouterUnVisiteurToolStripMenuItem.Click += new System.EventHandler(this.AjouterUnVisiteurToolStripMenuItem_Click);
            // 
            // supprimerUnVisiteurToolStripMenuItem
            // 
            this.supprimerUnVisiteurToolStripMenuItem.Name = "supprimerUnVisiteurToolStripMenuItem";
            this.supprimerUnVisiteurToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.supprimerUnVisiteurToolStripMenuItem.Text = "Supprimer un visiteur";
            this.supprimerUnVisiteurToolStripMenuItem.Click += new System.EventHandler(this.SupprimerUnVisiteurToolStripMenuItem_Click);
            // 
            // medicamentsToolStripMenuItem
            // 
            this.medicamentsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.listeDesMédicamentsToolStripMenuItem,
            this.ajouterUnMédicamentToolStripMenuItem,
            this.supprimerUnMédicamentToolStripMenuItem});
            this.medicamentsToolStripMenuItem.Name = "medicamentsToolStripMenuItem";
            this.medicamentsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.medicamentsToolStripMenuItem.Text = "&Medicaments";
            // 
            // listeDesMédicamentsToolStripMenuItem
            // 
            this.listeDesMédicamentsToolStripMenuItem.Name = "listeDesMédicamentsToolStripMenuItem";
            this.listeDesMédicamentsToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.listeDesMédicamentsToolStripMenuItem.Text = "Liste des médicaments";
            this.listeDesMédicamentsToolStripMenuItem.Click += new System.EventHandler(this.ListeDesMédicamentsToolStripMenuItem_Click);
            // 
            // ajouterUnMédicamentToolStripMenuItem
            // 
            this.ajouterUnMédicamentToolStripMenuItem.Name = "ajouterUnMédicamentToolStripMenuItem";
            this.ajouterUnMédicamentToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.ajouterUnMédicamentToolStripMenuItem.Text = "Ajouter un médicament";
            this.ajouterUnMédicamentToolStripMenuItem.Click += new System.EventHandler(this.AjouterUnMédicamentToolStripMenuItem_Click);
            // 
            // supprimerUnMédicamentToolStripMenuItem
            // 
            this.supprimerUnMédicamentToolStripMenuItem.Name = "supprimerUnMédicamentToolStripMenuItem";
            this.supprimerUnMédicamentToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.supprimerUnMédicamentToolStripMenuItem.Text = "Supprimer un médicament";
            this.supprimerUnMédicamentToolStripMenuItem.Click += new System.EventHandler(this.SupprimerUnMédicamentToolStripMenuItem_Click);
            // 
            // offreToolStripMenuItem
            // 
            this.offreToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ajouterUneQuantitéToolStripMenuItem});
            this.offreToolStripMenuItem.Name = "offreToolStripMenuItem";
            this.offreToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.offreToolStripMenuItem.Text = "&Offre";
            // 
            // ajouterUneQuantitéToolStripMenuItem
            // 
            this.ajouterUneQuantitéToolStripMenuItem.Name = "ajouterUneQuantitéToolStripMenuItem";
            this.ajouterUneQuantitéToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.ajouterUneQuantitéToolStripMenuItem.Text = "&Ajouter une quantité";
            this.ajouterUneQuantitéToolStripMenuItem.Click += new System.EventHandler(this.ajouterUneQuantitéToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1127, 492);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Acceuil || GSB";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridViewTextBoxColumn date;
        private System.Windows.Forms.DataGridViewTextBoxColumn motif;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gestionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem medicamentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listeDesMédicamentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajouterUnMédicamentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem supprimerUnMédicamentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rapportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listeDesRapportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajouterUnRapportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem suprimerUnRapportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visiteursToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listeDesVisiteursToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajouterUnVisiteurToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem supprimerUnVisiteurToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem praticiensToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listeDesPraticiensToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajouterUnPraticienToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem supprimerUnPraticienToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem offreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajouterUneQuantitéToolStripMenuItem;
    }
}

