﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace GSB_CS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }


        #region Médicaments
        ////////////////////////////////////////////////////// Médecicaments /////////////////////////////////////////////////////////////
        private void ListeDesMédicamentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms) // Verify if all form opened there is one with
            {
                if (f.Text == "Liste des medicaments")// That name
                {
                    isOpen = true; // Define that form is opened
                    f.Focus(); // Push the form to the foreground
                    break;
                }
            }
            if (isOpen == false) //else
            {
                FormMedicament liste = new FormMedicament
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                liste.Show();
            }
        }

        private void AjouterUnMédicamentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Ajouter un médicament")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormMedicamentAdd addMedic = new FormMedicamentAdd
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                addMedic.Show();
            }
        }

        private void SupprimerUnMédicamentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Supprimer un médicament")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormMedicamentDelete delMedic = new FormMedicamentDelete
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                delMedic.Show();
            }

        }
        #endregion



        #region Rapports
        ///////////////////////////////////////////////////////// Rapports /////////////////////////////////////////////////////////////
        private void ListeDesRapportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Liste des rapports")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormRapport liste = new FormRapport
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                liste.Show();
            }
        }

        private void AjouterUnRapportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Ajouter un rapport")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormRapportAdd addRap = new FormRapportAdd
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                addRap.Show();
            }
        }

        private void SuprimerUnRapportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Supprimer un rapport")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormRapportDelete delRap = new FormRapportDelete
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                delRap.Show();
            }
        }
        #endregion



        #region Médecins
        ///////////////////////////////////////////////////////// Médecins /////////////////////////////////////////////////////////////
        private void ListeDesPraticiensToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach(Form f in Application.OpenForms)
            {
                if(f.Text == "Liste praticiens")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if(isOpen == false)
            {
                FormMedecin liste = new FormMedecin
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                liste.Show();
            }
        }

        private void AjouterUnPraticienToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Ajouter un praticien")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormMedecinAdd addMed = new FormMedecinAdd
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                addMed.Show();
            }
        }

        private void SupprimerUnPraticienToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Supprimer un praticien")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormMedecinDelete delMed = new FormMedecinDelete
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                delMed.Show();
            }
        }
        #endregion



        #region Visiteurs
        ///////////////////////////////////////////////////////// Visiteurs /////////////////////////////////////////////////////////////

        private void ListeDesVisiteursToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Liste des visiteurs")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormVisiteur liste = new FormVisiteur
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                liste.Show();
            }
        }

        private void AjouterUnVisiteurToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Ajouter un visiteur")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormVisiteurAdd addVis = new FormVisiteurAdd
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                addVis.Show();
            }
        }

        private void SupprimerUnVisiteurToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Supprimer un visiteur")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormVisiteurDelete delVis = new FormVisiteurDelete
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                delVis.Show();
            }
        }
        #endregion



        private void ajouterUneQuantitéToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isOpen = false;
            foreach (Form f in Application.OpenForms)
            {
                if (f.Text == "Supprimer un visiteur")
                {
                    isOpen = true;
                    f.Focus();
                    break;
                }
            }
            if (isOpen == false)
            {
                FormOffrir Offr = new FormOffrir
                {
                    // Set the parent form of the child window.
                    MdiParent = this
                };
                // Display the new form.
                Offr.Show();
            }
        }
    }
}
