﻿namespace GSB_CS
{
    partial class FormRapportAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rtx_Motif = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rtx_BilanRapport = new System.Windows.Forms.RichTextBox();
            this.List_visiteur = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.list_Visireur = new System.Windows.Forms.ComboBox();
            this.list_medecin = new System.Windows.Forms.ComboBox();
            this.date_Rapport = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(536, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(266, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "Ajout de Rapport. ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(56, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(158, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Date du Rapport : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(56, 248);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Motif du rapport :";
            // 
            // rtx_Motif
            // 
            this.rtx_Motif.Location = new System.Drawing.Point(60, 292);
            this.rtx_Motif.Name = "rtx_Motif";
            this.rtx_Motif.Size = new System.Drawing.Size(1229, 55);
            this.rtx_Motif.TabIndex = 5;
            this.rtx_Motif.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(56, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Bilan du rapport :";
            // 
            // rtx_BilanRapport
            // 
            this.rtx_BilanRapport.Location = new System.Drawing.Point(60, 392);
            this.rtx_BilanRapport.Name = "rtx_BilanRapport";
            this.rtx_BilanRapport.Size = new System.Drawing.Size(1229, 61);
            this.rtx_BilanRapport.TabIndex = 7;
            this.rtx_BilanRapport.Text = "";
            // 
            // List_visiteur
            // 
            this.List_visiteur.AutoSize = true;
            this.List_visiteur.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.List_visiteur.Location = new System.Drawing.Point(56, 498);
            this.List_visiteur.Name = "List_visiteur";
            this.List_visiteur.Size = new System.Drawing.Size(80, 20);
            this.List_visiteur.TabIndex = 9;
            this.List_visiteur.Text = "Visiteur :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(776, 498);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(91, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Médecin  :";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(523, 573);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(295, 54);
            this.button1.TabIndex = 12;
            this.button1.Text = "Confirmer ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // list_Visireur
            // 
            this.list_Visireur.FormattingEnabled = true;
            this.list_Visireur.Location = new System.Drawing.Point(146, 500);
            this.list_Visireur.Name = "list_Visireur";
            this.list_Visireur.Size = new System.Drawing.Size(363, 21);
            this.list_Visireur.TabIndex = 13;
            // 
            // list_medecin
            // 
            this.list_medecin.FormattingEnabled = true;
            this.list_medecin.Location = new System.Drawing.Point(873, 500);
            this.list_medecin.Name = "list_medecin";
            this.list_medecin.Size = new System.Drawing.Size(406, 21);
            this.list_medecin.TabIndex = 14;
            // 
            // date_Rapport
            // 
            this.date_Rapport.Location = new System.Drawing.Point(247, 170);
            this.date_Rapport.Name = "date_Rapport";
            this.date_Rapport.Size = new System.Drawing.Size(554, 20);
            this.date_Rapport.TabIndex = 15;
            // 
            // FormRapportAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 686);
            this.Controls.Add(this.date_Rapport);
            this.Controls.Add(this.list_medecin);
            this.Controls.Add(this.list_Visireur);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.List_visiteur);
            this.Controls.Add(this.rtx_BilanRapport);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rtx_Motif);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormRapportAdd";
            this.Text = "Ajouter un rapport";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormRapportAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox rtx_Motif;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox rtx_BilanRapport;
        private System.Windows.Forms.Label List_visiteur;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox list_Visireur;
        private System.Windows.Forms.ComboBox list_medecin;
        private System.Windows.Forms.DateTimePicker date_Rapport;
    }
}