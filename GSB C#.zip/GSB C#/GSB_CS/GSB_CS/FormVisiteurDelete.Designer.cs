﻿namespace GSB_CS
{
    partial class FormVisiteurDelete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_ComfirmSupp = new System.Windows.Forms.Button();
            this.gb_comfirmSupp = new System.Windows.Forms.GroupBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.cb_yes = new System.Windows.Forms.CheckBox();
            this.list_Visiteur = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gb_comfirmSupp.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_ComfirmSupp
            // 
            this.btn_ComfirmSupp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ComfirmSupp.Location = new System.Drawing.Point(471, 563);
            this.btn_ComfirmSupp.Name = "btn_ComfirmSupp";
            this.btn_ComfirmSupp.Size = new System.Drawing.Size(373, 70);
            this.btn_ComfirmSupp.TabIndex = 8;
            this.btn_ComfirmSupp.Text = "Confirmer ";
            this.btn_ComfirmSupp.UseVisualStyleBackColor = true;
            this.btn_ComfirmSupp.Click += new System.EventHandler(this.btn_ComfirmSupp_Click);
            // 
            // gb_comfirmSupp
            // 
            this.gb_comfirmSupp.Controls.Add(this.checkBox2);
            this.gb_comfirmSupp.Controls.Add(this.cb_yes);
            this.gb_comfirmSupp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_comfirmSupp.Location = new System.Drawing.Point(306, 323);
            this.gb_comfirmSupp.Name = "gb_comfirmSupp";
            this.gb_comfirmSupp.Size = new System.Drawing.Size(709, 163);
            this.gb_comfirmSupp.TabIndex = 7;
            this.gb_comfirmSupp.TabStop = false;
            this.gb_comfirmSupp.Text = "Êtes-vous sur de vouloir Supprimer ?  ";
            this.gb_comfirmSupp.Visible = false;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(382, 64);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(181, 24);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Ne supprimez pas !";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // cb_yes
            // 
            this.cb_yes.AutoSize = true;
            this.cb_yes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_yes.Location = new System.Drawing.Point(26, 64);
            this.cb_yes.Name = "cb_yes";
            this.cb_yes.Size = new System.Drawing.Size(230, 24);
            this.cb_yes.TabIndex = 0;
            this.cb_yes.Text = "Vous pouvez supprimer ! ";
            this.cb_yes.UseVisualStyleBackColor = true;
            // 
            // list_Visiteur
            // 
            this.list_Visiteur.FormattingEnabled = true;
            this.list_Visiteur.Location = new System.Drawing.Point(145, 245);
            this.list_Visiteur.Name = "list_Visiteur";
            this.list_Visiteur.Size = new System.Drawing.Size(1029, 21);
            this.list_Visiteur.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(570, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 25);
            this.label1.TabIndex = 10;
            this.label1.Text = "Supprimer Visiteur";
            // 
            // FormVisiteurDelete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 686);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.list_Visiteur);
            this.Controls.Add(this.btn_ComfirmSupp);
            this.Controls.Add(this.gb_comfirmSupp);
            this.Name = "FormVisiteurDelete";
            this.Text = "Supprimer un visiteur";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormVisiteurDelete_Load);
            this.gb_comfirmSupp.ResumeLayout(false);
            this.gb_comfirmSupp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_ComfirmSupp;
        private System.Windows.Forms.GroupBox gb_comfirmSupp;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox cb_yes;
        private System.Windows.Forms.ComboBox list_Visiteur;
        private System.Windows.Forms.Label label1;
    }
}