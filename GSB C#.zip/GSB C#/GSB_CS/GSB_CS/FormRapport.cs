﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassesPasserelles;
using ClassesMetiers;
using System.Windows.Forms;

namespace GSB_CS
{
    public partial class FormRapport : Form
    {
        public FormRapport()
        {
            InitializeComponent();
        }

        private void LoadRapport() //Load all datas and refresh them if needed
        {
            List<Rapport> lesRapports = new List<Rapport>();  // Create list that'll receive all datas
            lesRapports = RapportPass.GetRapports(); // Get Rapport from database
            foreach (Rapport r in lesRapports)
            {
                DGrapport.Rows.Add(r.Id, r.Date, r.Motif, r.Bilan, r.IdVisiteur,r.NomVisiteur, r.IdMedecin , r.NomMedecin); //Add to datagrind view

            }

            List<Visiteur> LesVisiteurs = new List<Visiteur>(); // Prepare list that receive Visiteur
            LesVisiteurs = VisiteurPass.GetVisiteurs(); // Get Visiteur from database
            ListVisiteur.DisplayMember = "unNom"; // Visiteur information that's displayed
            ListVisiteur.ValueMember = "id"; //Visiteur value
            ListVisiteur.DataSource = LesVisiteurs; // Select where datas came from

            List<Medecin> LesMedecins = new List<Medecin>(); // Prepare list that receive Medecin
            LesMedecins = MedecinPass.GetMedecins(); // Get Medecin from database
            ListMedecin.DisplayMember = "nom"; // Medecin information that's displayed
            ListMedecin.ValueMember = "id"; //Medecin value
            ListMedecin.DataSource = LesMedecins; // Select where datas came from
        }

        private void FormRapport_Load(object sender, EventArgs e)
        {

            LoadRapport();  //Load Rapport to the list on form load
            Date_ModifRapport.Format = DateTimePickerFormat.Custom; //Create custom date format
            Date_ModifRapport.CustomFormat = "yyyy-MM-dd";
        }

        private void btn_ModifRapport_Click(object sender, EventArgs e)
        {
            if(GB_ModifRapport.Visible == false) // Displaying Update form
            {
                GB_ModifRapport.Visible = true;
            }
        }

        private void DGrapport_CellContentClick(object sender, DataGridViewCellEventArgs e) // Get datas for the update form
        {
            string date = DGrapport.CurrentRow.Cells[1].Value.ToString();
            Date_ModifRapport.Value = DateTime.Parse(date);
            Rtx_Motif.Text = DGrapport.CurrentRow.Cells[2].Value.ToString();
            Rtx_Bilan.Text = DGrapport.CurrentRow.Cells[3].Value.ToString();

            string idVisi = DGrapport.CurrentRow.Cells[4].Value.ToString();
            ListVisiteur.SelectedIndex = Int32.Parse(idVisi)-1;
            string idMed = DGrapport.CurrentRow.Cells[6].Value.ToString();
            ListMedecin.SelectedIndex = Int32.Parse(idMed)-1;
        }

        private void btn_ComfirmRapport_Click(object sender, EventArgs e) //Update function
        {
            string id = DGrapport.CurrentRow.Cells[0].Value.ToString();
            string date = Date_ModifRapport.Text;
            string motif = Rtx_Motif.Text;
            string bilan = Rtx_Bilan.Text;
            string visiteur = ListVisiteur.SelectedValue.ToString();
            string medecin = ListMedecin.SelectedValue.ToString();

            string champ = "SET date = '" + date + "', motif = '" + motif + "', bilan = '" + bilan + "', idVisiteur = '" + visiteur + "', idMedecin = '" + medecin +"'";
            try
            {
                RapportPass.UpdateRapport(id, champ);
                MessageBox.Show("Le rapport à été modifié");
            }
            catch (Exception err)
            {
                MessageBox.Show("Erreur : " + err);
            }
            DGrapport.Rows.Clear();
            Rtx_Bilan.Clear();
            Rtx_Motif.Clear();


            LoadRapport();
        }
    }

}
