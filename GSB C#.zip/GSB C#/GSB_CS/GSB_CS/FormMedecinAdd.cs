﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassesPasserelles;
using ClassesMetiers;

namespace GSB_CS
{
    public partial class FormMedecinAdd : Form
    {
        public FormMedecinAdd()
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e) // Get datas from the form
        {
            string nom = Tx_NomMedecin.Text;
            string prenom = Tx_PrenomMedecin.Text;
            string tel = Tx_TelMedecin.Text;
            string adr = Tx_AdrMedecin.Text;
            string cp = Tx_CpMedecin.Text;


            string spe = listSpe.SelectedValue.ToString(); // Get value from Specialite list


            try
            {
                MedecinPass.InsertMedecin(nom, prenom, adr, tel, cp, spe); //Insert medecin in database
                MessageBox.Show("Le medecin à été ajouté");
            }
            catch (Exception err)
            {
                MessageBox.Show("Erreur : " + err);
            }

        }

        private void FormMedecinAdd_Load(object sender, EventArgs e) //Create Specialite list
        {
            List<Specialite> LeSpecialites = new List<Specialite>();
            LeSpecialites = SpecialitePass.GetSpecialites();

            listSpe.DisplayMember = "Libelle"; // Specialite information that's displayed
            listSpe.ValueMember = "ID"; //Specialite value
            listSpe.DataSource = LeSpecialites; // Select where datas came from
        }
    }
}
