﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMetiers
{
    public class Rapport
    {

        //Properties

        private double id;
        private string date;
        private string motif;
        private string bilan;
        private double idVisiteur;
        private string nomVisiteur;
        private double idMedecin;
        private string nomMedecin;

        //Accessor
        public double Id { get => id; set => id = value; }
        public string Date { get => date; set => date = value; }
        public string Motif { get => motif; set => motif = value; }
        public string Bilan { get => bilan; set => bilan = value; }
        public double IdVisiteur { get => idVisiteur; set => idVisiteur = value; }
        public string NomVisiteur { get => nomVisiteur; set => nomVisiteur = value; }
        public double IdMedecin { get => idMedecin; set => idMedecin = value; }
        public string NomMedecin { get => nomMedecin; set => nomMedecin = value; }



        //Constructor
        public Rapport()
        { //Always useful to have a constructor with empty parameters
        }


        // It's use when we load all the lists
        public Rapport(double id, string date, string motif, string bilan, double idV, double idM, string NomV , string NomM)
        {

            Id = id;
            Date = date;
            Motif = motif;
            Bilan = bilan;
            IdMedecin = idM;
            IdVisiteur = idV;
            NomVisiteur = NomV;
            NomMedecin = NomM;
        }

        //Class metthods

        // Return all informations 
        public override string ToString()
        {
            return Id + " " + Date+" "+ Motif +" "+ Bilan +" "+IdVisiteur+" "+IdMedecin;
        }


    }
}
