﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMetiers
{
    public class Medecin
    {

        //Properties

        private double id;
        private string nom;
        private string prenom;
        private string adresse;
        private string tel;
        private string departement;
        private double idSpe;
        private string libel;

        //Accessor
        public double Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom { get => prenom; set => prenom = value; }
        public string Adresse { get => adresse; set => adresse = value; }
        public string Tel { get => tel; set => tel = value; }
        public string Departement { get => departement; set => departement = value; }
        public double IdSpe { get => idSpe; set => idSpe = value; }
        public string Libel { get => libel; set => libel = value; }

        //Constructor
        public Medecin()
        { //Always useful to have a constructor with empty parameters
        }

        // It's use when we load all the lists
        public Medecin(double idM, string name, string firstname, string address, string cellphone, string department, double specialityID , string Libelle)
        {
            id = idM;
            nom = name;
            prenom = firstname;
            adresse = address;
            tel = cellphone;
            departement = department;
            idSpe = specialityID;
            libel = Libelle;
        }

        //Class metthods

        // (Who am I) Just to get lastname/firstname
        public string wai()
        {
            return "Je suis : " + this.nom + this.prenom;
        }
        // Return all informations
        public override string ToString()
        {
            return id + " " + nom + " " + prenom + " " + adresse + " " + tel + " " + departement + " " + idSpe;
        }


    }
}
