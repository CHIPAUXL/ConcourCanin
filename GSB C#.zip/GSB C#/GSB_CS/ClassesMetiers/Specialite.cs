﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMetiers
{
    public class Specialite
    {
        //Properties
        private string id;
        private string libelle;

        //Accessors
        public string Id { get => id; set => id = value; }
        public string Libelle { get => libelle; set => libelle = value; }

        //Constructor

        // It's use when we load all the lists
        public Specialite (string idSpe, string lbl)
        {
            Id = idSpe;
            Libelle = lbl;
        }

        //Class Methods

        // Return all informations 
        public override string ToString()
        {
            return Id + " - "+Libelle;
        }



    }
}
