﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMetiers
{
    public class Offrir
    {
        //Properties

        private double idMedi;
        private string nomMedi;
        private double idRap;

        private int quantite;


        //Accessor

        public double IdMedi { get => idMedi; set => idMedi = value; }
        public double IdRap { get => idRap; set => idRap = value; }
        public int Quantite { get => quantite; set => quantite = value; }
        public string NomMedi { get => nomMedi; set => nomMedi = value; }



        //Constructor

        public Offrir()
        {

        }
        // It's use when we load all the lists
        public Offrir(double idM, double rapport, int UneQuantite , string unNomMedi   )
        {
            IdMedi = idM;
            IdRap = rapport;
            Quantite = UneQuantite;
            NomMedi = unNomMedi;
        }

        // Return all informations
        public override string ToString()
        {
            return IdMedi + " " + IdRap + " " + Quantite ;
        }
    }
}
