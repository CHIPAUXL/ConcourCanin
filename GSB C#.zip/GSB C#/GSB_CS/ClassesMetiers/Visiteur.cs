﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMetiers
{
    public class Visiteur
    {
        //Properties

        private double id;
        private string unNom;
        private string unPrenom;
        private string unLogin;
        private string unMdp;
        private string uneAdresse;
        private string unCp;
        private string uneVille;
        private string dateEmbauche;

        //Assessor
        public double Id { get => id; set => id = value; }
        public string UnNom { get => unNom; set => unNom = value; }
        public string UnPrenom { get => unPrenom; set => unPrenom = value; }
        public string UnLogin { get => unLogin; set => unLogin = value; }
        public string UnMdp { get => unMdp; set => unMdp = value; }
        public string UneAdresse { get => uneAdresse; set => uneAdresse = value; }
        public string UnCp { get => unCp; set => unCp = value; }
        public string UneVille { get => uneVille; set => uneVille = value; }
        public string DateEmbauche { get => dateEmbauche; set => dateEmbauche = value; }

        //Constructor
        // It's use when we load all the lists
        public Visiteur(double unId, string name, string firstname, string login, string mdp, string address, string cp, string city, string date)
        {
            Id = unId;
            UnNom = name;
            UnPrenom = firstname;
            unLogin = login;
            UnMdp = mdp;
            UneAdresse = address;
            UnCp = cp;
            UneVille = city;
            DateEmbauche = date;

        }

        //Class Method's

        // (Who am I) Just to get lastname/firstname
        public string wai()
        {
            return "Je suis : " + this.UnNom + this.UnPrenom;
        }

        // Return all informations
        public override string ToString()
        {
            return id + " " + UnNom + " " + UnPrenom + " " + UneAdresse + " " + UneVille + " " + UnCp + " " + UnLogin + " " + UnMdp + " " + DateEmbauche;
        }
    }
}
