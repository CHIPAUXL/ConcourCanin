﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMetiers
{
   public  class Famille
    {


            //Properties

            private double id;
            private string libelle;

            //Accessor
            public double Id { get => id; set => id = value; }
            public string Libelle { get => libelle; set => libelle = value; }


        //Constructor
        public Famille()
            { //Always useful to have a constructor with empty parameters
            }

            // It's use when we load all the lists
            public Famille(double idSpe, string libelleSpe)
            {

                Id = idSpe;
                Libelle = libelleSpe;
            }

            //Class metthods

            // (Who am I) Just to get lastname/firstname

            public string wai()
            {
                return "Je suis : " + this.Id + this.Libelle;
            }

            // Return all informations
            public override string ToString()
            {
                return Id + " " + Libelle;
            }


   }

}
