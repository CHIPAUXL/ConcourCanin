﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesMetiers
{
    public class Medicament
    {
        //Properties

        private double id;
        private string nom;
        private string composition;
        private string effet;
        private string contreIndic;
        private double idFam;
        private string libFam;

        //Accessor
        public double Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Composition { get => composition; set => composition = value; }
        public string Effet { get => effet; set => effet = value; }
        public string ContreIndic { get => contreIndic; set => contreIndic = value; }
        public double IdFam { get => idFam; set => idFam = value; }
        public string LibFam { get => libFam; set => libFam = value; }

        //Constructor
        public Medicament()
        { //Always useful to have a constructor with empty parameters
        }
        // It's use when we load all the lists

        public Medicament(double idM, string name, string compo, string effects, string cIndication, double fam , string libel )
        {
            Id = idM;
            Nom = name;
            Composition = compo;
            Effet = effects;
            ContreIndic = cIndication;
            IdFam = fam;
            LibFam = libel;
        }

        //Class metthods

        // Return all informations
        public override string ToString()
        {
            return Id + " " + Nom + " " + Composition + " " + Effet + " " + ContreIndic + IdFam;
        }


    }
}
