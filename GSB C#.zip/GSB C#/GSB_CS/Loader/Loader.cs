﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassesPasserelles;
using ClassesMetiers;


namespace Loader
{

    public class DatasLoader
    {
        public DatasLoader()
        {

        }
        public string LoadDatas()
        {
            try
            {
                /////////////////////////////////////////////  Médecins /////////////////////////////////////////////
                List<Medecin> lesMedecin = new List<Medecin>(); // Create list
                lesMedecin = MedecinPass.GetMedecins(); //Load datas from database

                /////////////////////////////////////////////  Visiteurs /////////////////////////////////////////////
                List<Visiteur> lesVisiteurs = new List<Visiteur>(); // Create list
                lesVisiteurs = VisiteurPass.GetVisiteurs(); //Load datas from database

                /////////////////////////////////////////////  Médicaments /////////////////////////////////////////////
                List<Medicament> lesM = new List<Medicament>(); // Create list
                lesM = MedicamentPass.GetMedicaments(); //Load datas from database

                /////////////////////////////////////////////  Rapport /////////////////////////////////////////////
                List<Rapport> lesR = new List<Rapport>(); // Create list
                lesR = RapportPass.GetRapports(); //Load datas from database

                /////////////////////////////////////////////  Spécialité /////////////////////////////////////////////
                List<Specialite> lesS = new List<Specialite>(); // Create list
                lesS = SpecialitePass.GetSpecialites(); //Load datas from database

                return "L'application est chargée !";
            }
            catch
            {
                return "Oops une erreur s'est produite veuillez redémarrer l'application !";

            }



        }
    }
}
